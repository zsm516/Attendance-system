package ir.attendance.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
