import { createContext, useContext, useEffect, useState, useCallback } from 'react'
import { api } from './lib'

const Ctx = createContext(null)
export const useAuth = () => useContext(Ctx)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => { try { return JSON.parse(localStorage.getItem('user')) } catch { return null } })
  const [ready, setReady] = useState(false)
  const save = (data) => {
    localStorage.setItem('access', data.access); localStorage.setItem('refresh', data.refresh)
    localStorage.setItem('user', JSON.stringify(data.user)); setUser(data.user)
  }
  const logout = useCallback(() => {
    ;['access', 'refresh', 'user'].forEach((k) => localStorage.removeItem(k)); setUser(null)
  }, [])
  const refreshMe = useCallback(async () => {
    const { data } = await api.get('/auth/me/'); localStorage.setItem('user', JSON.stringify(data)); setUser(data); return data
  }, [])
  const login = async (phone, password) => { const { data } = await api.post('/auth/login/', { phone, password }); save(data); return data.user }
  const registerCompany = async (body) => { const { data } = await api.post('/auth/register-company/', body); save(data); return data.user }

  useEffect(() => {
    const h = () => setUser(null)
    window.addEventListener('auth:logout', h)
    if (localStorage.getItem('access')) refreshMe().catch(() => {}).finally(() => setReady(true)); else setReady(true)
    return () => window.removeEventListener('auth:logout', h)
  }, [refreshMe])

  return <Ctx.Provider value={{ user, ready, login, logout, registerCompany, refreshMe }}>{children}</Ctx.Provider>
}
