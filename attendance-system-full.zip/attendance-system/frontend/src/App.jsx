import { Navigate, Route, Routes } from 'react-router-dom'
import { useAuth } from './auth'
import Layout from './Layout'
import { Login } from './pages/Auth'
import EmployeeHome from './pages/EmployeeHome'
import MyAttendance from './pages/MyAttendance'
import Leaves from './pages/Leaves'
import Notifications from './pages/Notifications'
import Profile from './pages/Profile'
import Dashboard from './pages/Dashboard'
import Employees from './pages/Employees'
import Reports from './pages/Reports'
import Settings from './pages/Settings'
import { Spinner } from './components'

export default function App() {
  const { user, ready } = useAuth()
  if (!ready) return <Spinner />
  if (!user) return <Routes><Route path="*" element={<Login />} /></Routes>
  const mgr = user.role === 'manager'
  return (
    <Layout>
      <Routes>
        {mgr ? (<>
          <Route path="/" element={<Dashboard />} />
          <Route path="/employees" element={<Employees />} />
          <Route path="/leaves" element={<Leaves />} />
          <Route path="/reports" element={<Reports />} />
          <Route path="/settings" element={<Settings />} />
        </>) : (<>
          <Route path="/" element={<EmployeeHome />} />
          <Route path="/attendance" element={<MyAttendance />} />
          <Route path="/leaves" element={<Leaves />} />
        </>)}
        <Route path="/notifications" element={<Notifications />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Layout>
  )
}
