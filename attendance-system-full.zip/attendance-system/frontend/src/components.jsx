import { useEffect, useState } from 'react'
import { curJalali, fa, isoToJ, jMonthLen, jToIso, MONTHS, STATUS } from './lib'

const P = {
  home: 'M3 11l9-8 9 8v10a1 1 0 01-1 1h-5v-7H9v7H4a1 1 0 01-1-1z',
  clock: 'M12 7v5l3 2M12 22a10 10 0 110-20 10 10 0 010 20z',
  users: 'M17 21v-2a4 4 0 00-4-4H7a4 4 0 00-4 4v2M10 11a4 4 0 100-8 4 4 0 000 8M21 21v-2a4 4 0 00-3-3.9M16 3.1a4 4 0 010 7.8',
  cal: 'M8 2v4M16 2v4M3 9h18M5 4h14a2 2 0 012 2v14a2 2 0 01-2 2H5a2 2 0 01-2-2V6a2 2 0 012-2z',
  bell: 'M18 8a6 6 0 10-12 0c0 7-3 9-3 9h18s-3-2-3-9M13.7 21a2 2 0 01-3.4 0',
  chart: 'M3 3v18h18M7 15l4-4 3 3 5-6',
  gear: 'M12 15a3 3 0 100-6 3 3 0 000 6zM19.4 15a1.7 1.7 0 00.3 1.8l.1.1a2 2 0 11-2.8 2.8l-.1-.1a1.7 1.7 0 00-1.8-.3 1.7 1.7 0 00-1 1.5V21a2 2 0 11-4 0v-.1a1.7 1.7 0 00-1.1-1.5 1.7 1.7 0 00-1.8.3l-.1.1a2 2 0 11-2.8-2.8l.1-.1a1.7 1.7 0 00.3-1.8 1.7 1.7 0 00-1.5-1H3a2 2 0 110-4h.1a1.7 1.7 0 001.5-1.1 1.7 1.7 0 00-.3-1.8l-.1-.1a2 2 0 112.8-2.8l.1.1a1.7 1.7 0 001.8.3H9a1.7 1.7 0 001-1.5V3a2 2 0 114 0v.1a1.7 1.7 0 001 1.5 1.7 1.7 0 001.8-.3l.1-.1a2 2 0 112.8 2.8l-.1.1a1.7 1.7 0 00-.3 1.8V9a1.7 1.7 0 001.5 1H21a2 2 0 110 4h-.1a1.7 1.7 0 00-1.5 1z',
  user: 'M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2M12 11a4 4 0 100-8 4 4 0 000 8',
  out: 'M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4M16 17l5-5-5-5M21 12H9',
  help: 'M12 22a10 10 0 110-20 10 10 0 010 20zM9.1 9a3 3 0 015.8 1c0 2-3 3-3 3M12 17h.01',
  plus: 'M12 5v14M5 12h14', x: 'M18 6L6 18M6 6l12 12', pin: 'M12 22s7-6.5 7-12a7 7 0 10-14 0c0 5.5 7 12 7 12zM12 12a2 2 0 100-4 2 2 0 000 4z',
  dl: 'M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4M7 10l5 5 5-5M12 15V3',
}
export const Icon = ({ n, size = 20 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round"><path d={P[n]} /></svg>
)

export function Modal({ title, onClose, children }) {
  useEffect(() => { const h = (e) => e.key === 'Escape' && onClose(); window.addEventListener('keydown', h); return () => window.removeEventListener('keydown', h) }, [onClose])
  return (
    <div className="modal-bg" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className="modal">
        <div className="row between" style={{ marginBottom: 12 }}><h3 style={{ margin: 0 }}>{title}</h3><button className="btn sm" onClick={onClose}><Icon n="x" size={16} /></button></div>
        {children}
      </div>
    </div>
  )
}

export function StatusChip({ s }) { const m = STATUS[s] || STATUS.off; return <span className={`chip ${m.c}`}>{m.mk && <b>{m.mk}</b>}{m.t}</span> }

/** Jalali date picker (selects). value / onChange use ISO Gregorian 'YYYY-MM-DD'. */
export function JalaliField({ value, onChange, label }) {
  const cur = curJalali()
  const j = value ? isoToJ(value) : cur
  const years = Array.from({ length: 6 }, (_, i) => cur.jy - 2 + i)
  const set = (y, m, d) => onChange(jToIso(y, m, Math.min(d, jMonthLen(y, m))))
  return (
    <label className="f">{label}
      <div className="row" style={{ gap: 6 }}>
        <select value={j.jd} onChange={(e) => set(j.jy, j.jm, +e.target.value)}>{Array.from({ length: jMonthLen(j.jy, j.jm) }, (_, i) => <option key={i} value={i + 1}>{fa(i + 1)}</option>)}</select>
        <select value={j.jm} onChange={(e) => set(j.jy, +e.target.value, j.jd)}>{MONTHS.map((m, i) => <option key={i} value={i + 1}>{m}</option>)}</select>
        <select value={j.jy} onChange={(e) => set(+e.target.value, j.jm, j.jd)}>{years.map((y) => <option key={y} value={y}>{fa(y)}</option>)}</select>
      </div>
    </label>
  )
}

export function MonthNav({ year, month, onChange }) {
  const go = (d) => { let m = month + d, y = year; if (m > 12) { m = 1; y++ } if (m < 1) { m = 12; y-- } onChange(y, m) }
  return (
    <div className="row between">
      <button className="btn sm" onClick={() => go(-1)}>‹ قبلی</button>
      <b>{MONTHS[month - 1]} {fa(year)}</b>
      <button className="btn sm" onClick={() => go(1)}>بعدی ›</button>
    </div>
  )
}

export function Spinner() { return <div className="center muted" style={{ padding: 30 }}>در حال بارگذاری…</div> }
export function Field({ label, children }) { return <label className="f">{label}{children}</label> }
