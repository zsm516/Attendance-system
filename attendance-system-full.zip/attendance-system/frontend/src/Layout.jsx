import { useEffect, useRef, useState } from 'react'
import { NavLink, useNavigate } from 'react-router-dom'
import { useAuth } from './auth'
import { api, mediaUrl, flushQueue, queue } from './lib'
import { Icon } from './components'

const MGR = [['/', 'home', 'داشبورد'], ['/employees', 'users', 'کارمندان'], ['/leaves', 'cal', 'مرخصی‌ها'], ['/reports', 'chart', 'گزارش‌ها'], ['/settings', 'gear', 'تنظیمات']]
const EMP = [['/', 'clock', 'ثبت حضور'], ['/attendance', 'cal', 'کارکرد من'], ['/leaves', 'users', 'مرخصی']]

function Clock() {
  const [now, setNow] = useState(new Date())
  useEffect(() => { const t = setInterval(() => setNow(new Date()), 1000); return () => clearInterval(t) }, [])
  const parts = Object.fromEntries(new Intl.DateTimeFormat('fa-IR-u-ca-persian', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }).formatToParts(now).map((x) => [x.type, x.value]))
  const date = `${parts.weekday} ${parts.day} ${parts.month} ${parts.year}`
  return <div className="clock"><div className="small muted">{date}</div><b>{now.toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}</b></div>
}

export default function Layout({ children }) {
  const { user, logout } = useAuth()
  const nav = useNavigate()
  const [open, setOpen] = useState(false)
  const [unread, setUnread] = useState(0)
  const [toast, setToast] = useState('')
  const ref = useRef()
  const mgr = user.role === 'manager'
  const items = mgr ? MGR : EMP

  useEffect(() => {
    const load = () => api.get('/notifications/unread_count/').then((r) => setUnread(r.data.count)).catch(() => {})
    load(); const t = setInterval(load, 30000); window.addEventListener('focus', load)
    return () => { clearInterval(t); window.removeEventListener('focus', load) }
  }, [])
  // offline queue sync (mobile/web share the same API)
  useEffect(() => {
    const run = async () => {
      if (!queue.all().length) return
      const r = await flushQueue()
      if (r) { setToast(`${r.done} رویداد آفلاین همگام شد`); setTimeout(() => setToast(''), 3500); window.dispatchEvent(new Event('attendance:synced')) }
    }
    run(); window.addEventListener('online', run); return () => window.removeEventListener('online', run)
  }, [])
  useEffect(() => { const h = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false) }; document.addEventListener('mousedown', h); return () => document.removeEventListener('mousedown', h) }, [])

  const initials = (user.full_name || '؟').trim().slice(0, 1)
  const go = (p) => { setOpen(false); nav(p) }
  return (
    <div className="app">
      <aside className="side">
        <div className="brand"><i>◷</i><span>حضور و غیاب</span></div>
        <nav className="nav col" style={{ gap: 4 }}>
          {items.map(([to, ic, t]) => <NavLink key={to} to={to} end={to === '/'}><Icon n={ic} />{t}</NavLink>)}
          <NavLink to="/notifications"><Icon n="bell" />اعلان‌ها{unread > 0 && <span className="badge">{unread}</span>}</NavLink>
        </nav>
        <div className="grow" />
        <div className="muted small" style={{ padding: 10 }}>{user.company_name}</div>
      </aside>
      <div className="main">
        <header className="top">
          <Clock />
          <div ref={ref} style={{ position: 'relative' }}>
            <button className="avatar" onClick={() => setOpen(!open)} aria-label="منو">
              {user.avatar ? <img src={mediaUrl(user.avatar)} alt="" /> : initials}
            </button>
            {open && (
              <div className="menu">
                <div style={{ padding: '8px 12px' }}><b>{user.full_name}</b><div className="small muted">{mgr ? 'مدیر' : 'کارمند'} · {user.company_name}</div></div>
                <hr />
                <button onClick={() => go('/profile')}><Icon n="user" />پروفایل کاربری</button>
                {mgr && <button onClick={() => go('/employees')}><Icon n="users" />کارمندان</button>}
                <button onClick={() => go('/notifications')}><Icon n="bell" />اعلان‌ها {unread > 0 && `(${unread})`}</button>
                <a href="mailto:support@example.com"><Icon n="help" />تماس با پشتیبانی</a>
                <hr />
                <button onClick={() => { setOpen(false); logout() }} style={{ color: '#fca5a5' }}><Icon n="out" />خروج</button>
              </div>
            )}
          </div>
        </header>
        <main className="content">{children}</main>
      </div>
      <nav className="bottom">
        {items.map(([to, ic, t]) => <NavLink key={to} to={to} end={to === '/'}><Icon n={ic} /><span>{t}</span></NavLink>)}
        <NavLink to="/notifications"><Icon n="bell" /><span>اعلان‌ها</span>{unread > 0 && <span className="badge">{unread}</span>}</NavLink>
      </nav>
      {toast && <div className="toast okmsg">{toast}</div>}
    </div>
  )
}
