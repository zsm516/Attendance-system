import axios from 'axios'
import { Capacitor } from '@capacitor/core'
import { toJalaali, toGregorian, jalaaliMonthLength } from 'jalaali-js'

export const isNative = () => { try { return Capacitor.isNativePlatform() } catch { return false } }

export const getApiBase = () => localStorage.getItem('api_base') || import.meta.env.VITE_API_URL || '/api/v1'
export const setApiBase = (v) => { v ? localStorage.setItem('api_base', v.replace(/\/+$/, '')) : localStorage.removeItem('api_base') }
export const mediaUrl = (p) => { if (!p) return null; if (/^https?:/.test(p)) return p; return getApiBase().replace(/\/api\/v1$/, '') + p }

export const api = axios.create({ timeout: 20000 })
const PUBLIC = ['/auth/login/', '/auth/register-company/', '/auth/refresh/']
api.interceptors.request.use((c) => {
  c.baseURL = getApiBase()
  c.headers['X-Client'] = isNative() ? 'mobile' : 'web'
  const t = localStorage.getItem('access')
  // never send a (possibly stale) token to public endpoints
  if (t && !PUBLIC.some((p) => (c.url || '').includes(p))) c.headers.Authorization = `Bearer ${t}`
  return c
})
let refreshing = null
api.interceptors.response.use((r) => r, async (err) => {
  const cfg = err.config || {}
  const isPublic = PUBLIC.some((p) => (cfg.url || '').includes(p))
  if (err.response?.status === 401 && !cfg._retry && !isPublic && localStorage.getItem('refresh')) {
    cfg._retry = true
    try {
      refreshing = refreshing || axios.post(getApiBase() + '/auth/refresh/', { refresh: localStorage.getItem('refresh') })
      const { data } = await refreshing
      refreshing = null
      localStorage.setItem('access', data.access)
      if (data.refresh) localStorage.setItem('refresh', data.refresh)
      return api(cfg)
    } catch (e) {
      refreshing = null
      localStorage.removeItem('access'); localStorage.removeItem('refresh'); localStorage.removeItem('user')
      window.dispatchEvent(new Event('auth:logout'))
    }
  }
  return Promise.reject(err)
})
export const errMsg = (e) => {
  if (!e.response) return 'ارتباط با سرور برقرار نشد. اینترنت یا آدرس سرور را بررسی کنید.'
  const d = e.response.data
  if (d?.detail) return String(d.detail)
  if (typeof d === 'object' && d) { const k = Object.keys(d)[0]; const v = d[k]; return `${Array.isArray(v) ? v[0] : v}` }
  return 'خطای نامشخص رخ داد.'
}
export const isNetworkError = (e) => !e.response

// ---- Jalali / format helpers
export const MONTHS = ['فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور','مهر','آبان','آذر','دی','بهمن','اسفند']
export const WEEKDAYS_PY = ['دوشنبه','سه‌شنبه','چهارشنبه','پنجشنبه','جمعه','شنبه','یکشنبه']
export const WEEK_ORDER = [5, 6, 0, 1, 2, 3, 4] // Saturday-first, python weekday numbers
export const fa = (n) => (n ?? '').toString().replace(/\d/g, (d) => '۰۱۲۳۴۵۶۷۸۹'[d])
export const iso = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
export const todayIso = () => iso(new Date())
export const isoToJ = (s) => { const [y, m, d] = s.split('-').map(Number); return toJalaali(y, m, d) }
export const jToIso = (jy, jm, jd) => { const g = toGregorian(jy, jm, jd); return `${g.gy}-${String(g.gm).padStart(2, '0')}-${String(g.gd).padStart(2, '0')}` }
export const jMonthLen = jaalaliLen
function jaalaliLen(y, m) { return jalaaliMonthLength(y, m) }
export const curJalali = () => isoToJ(todayIso())
export const jText = (s) => { if (!s) return ''; const j = isoToJ(s); return fa(`${j.jy}/${String(j.jm).padStart(2, '0')}/${String(j.jd).padStart(2, '0')}`) }
export const mins = (m) => { m = Math.max(0, Math.round(m || 0)); const h = Math.floor(m / 60), r = m % 60; return fa(`${h}:${String(r).padStart(2, '0')}`) }
export const pyWeekday = (isoStr) => { const d = new Date(isoStr + 'T12:00:00'); return (d.getDay() + 6) % 7 }
export const STATUS = {
  present: { t: 'حاضر', mk: '✓', c: 'present' }, absent: { t: 'غایب', mk: '✕', c: 'absent' },
  leave: { t: 'مرخصی', mk: '✕', c: 'leave' }, holiday: { t: 'تعطیل', mk: '✓', c: 'holiday' },
  pending: { t: 'در انتظار', mk: '…', c: 'pending' }, future: { t: '—', mk: '', c: 'future' }, off: { t: 'روز کاری نیست', mk: '', c: 'off' },
}

// ---- Offline punch queue (mobile sync)
const QK = 'punch_queue'
export const queue = {
  all: () => { try { return JSON.parse(localStorage.getItem(QK) || '[]') } catch { return [] } },
  push: (ev) => { const q = queue.all(); q.push(ev); localStorage.setItem(QK, JSON.stringify(q)) },
  set: (q) => localStorage.setItem(QK, JSON.stringify(q)),
}
export const uuid = () => (crypto.randomUUID ? crypto.randomUUID() : 'u' + Date.now() + Math.random().toString(16).slice(2))
export async function flushQueue() {
  const q = queue.all()
  if (!q.length) return null
  try {
    const { data } = await api.post('/attendance/sync/', { events: q })
    const done = new Set(data.results.filter((r) => r.ok).map((r) => r.client_uuid))
    // keep only transient failures out: drop permanently rejected events too, to avoid infinite retry
    queue.set([])
    return { results: data.results, done: done.size, failed: data.results.filter((r) => !r.ok) }
  } catch (e) { return null }
}
