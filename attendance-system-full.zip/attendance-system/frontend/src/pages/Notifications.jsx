import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { api, errMsg, fa } from '../lib'
import { Spinner } from '../components'

export default function Notifications() {
  const [list, setList] = useState(null)
  const [err, setErr] = useState('')
  const nav = useNavigate()
  const load = () => api.get('/notifications/').then((r) => setList(r.data.results)).catch((e) => setErr(errMsg(e)))
  useEffect(() => { load() }, [])
  const open = async (n) => { if (!n.is_read) await api.post(`/notifications/${n.id}/read/`).catch(() => {}); if (n.kind === 'leave') nav('/leaves'); else load() }
  const all = async () => { await api.post('/notifications/read_all/'); load() }
  return (
    <div className="col" style={{ gap: 12 }}>
      <div className="row between"><h3>اعلان‌ها</h3><button className="btn sm" onClick={all}>علامت‌گذاری همه به‌عنوان خوانده‌شده</button></div>
      {err && <div className="err">{err}</div>}
      {!list ? <Spinner /> : list.length === 0 ? <div className="card muted center">اعلانی وجود ندارد.</div> :
        list.map((n) => (
          <div key={n.id} className="card" style={{ cursor: 'pointer', borderColor: n.is_read ? 'var(--line)' : 'var(--brand)' }} onClick={() => open(n)}>
            <div className="row between"><b>{n.title}</b><span className="muted small">{fa(new Date(n.created_at).toLocaleString('fa-IR', { dateStyle: 'short', timeStyle: 'short' }))}</span></div>
            {n.body && <div className="muted">{n.body}</div>}
          </div>))}
    </div>
  )
}
