import { useEffect, useState } from 'react'
import { Geolocation } from '@capacitor/geolocation'
import { api, errMsg, fa, jText, todayIso, WEEK_ORDER, WEEKDAYS_PY } from '../lib'
import { Field, Icon, JalaliField, Spinner } from '../components'

export default function Settings() {
  const [c, setC] = useState(null)
  const [hol, setHol] = useState([])
  const [h, setH] = useState({ date: todayIso(), title: '' })
  const [msg, setMsg] = useState(''), [err, setErr] = useState('')
  const loadH = () => api.get('/company/holidays/').then((r) => setHol(r.data))
  useEffect(() => { api.get('/company/').then((r) => setC(r.data)).catch((e) => setErr(errMsg(e))); loadH() }, [])
  if (!c) return err ? <div className="err">{err}</div> : <Spinner />
  const set = (k) => (e) => setC({ ...c, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value })
  const toggleDay = (w) => setC({ ...c, weekend_days: c.weekend_days.includes(w) ? c.weekend_days.filter((x) => x !== w) : [...c.weekend_days, w] })
  const here = async () => { try { const p = await Geolocation.getCurrentPosition({ enableHighAccuracy: true, timeout: 12000 }); setC({ ...c, latitude: p.coords.latitude.toFixed(6), longitude: p.coords.longitude.toFixed(6) }) } catch { setErr('دریافت موقعیت ممکن نشد.') } }
  const save = async (e) => {
    e.preventDefault(); setErr('')
    try { const { data } = await api.patch('/company/', { ...c, latitude: c.latitude || null, longitude: c.longitude || null, radius_m: +c.radius_m, grace_minutes: +c.grace_minutes }); setC(data); setMsg('تنظیمات ذخیره شد.'); setTimeout(() => setMsg(''), 3000) } catch (x) { setErr(errMsg(x)) }
  }
  const addH = async (e) => { e.preventDefault(); try { await api.post('/company/holidays/', h); setH({ ...h, title: '' }); loadH() } catch (x) { setErr(errMsg(x)) } }
  return (
    <div className="col" style={{ gap: 14 }}>
      <h2>تنظیمات شرکت</h2>
      {(msg || err) && <div className={msg ? 'okmsg' : 'err'}>{msg || err}</div>}
      <form className="card col" onSubmit={save}>
        <Field label="نام شرکت"><input required value={c.name} onChange={set('name')} /></Field>
        <div><div className="muted small" style={{ marginBottom: 6 }}>روزهای تعطیل هفتگی</div>
          <div className="row wrap">{WEEK_ORDER.map((w) => <label key={w} className={`chip ${c.weekend_days.includes(w) ? 'holiday' : 'off'}`} style={{ cursor: 'pointer' }}><input type="checkbox" checked={c.weekend_days.includes(w)} onChange={() => toggleDay(w)} style={{ display: 'none' }} />{WEEKDAYS_PY[w]}</label>)}</div></div>
        <Field label="مهلت تأخیر مجاز (دقیقه)"><input type="number" min="0" dir="ltr" value={c.grace_minutes} onChange={set('grace_minutes')} /></Field>
        <label className="row"><input type="checkbox" checked={c.require_location} onChange={set('require_location')} />الزام ثبت ورود/خروج داخل محدوده‌ی جغرافیایی شرکت</label>
        <div className="grid g3">
          <Field label="عرض جغرافیایی"><input dir="ltr" value={c.latitude ?? ''} onChange={set('latitude')} /></Field>
          <Field label="طول جغرافیایی"><input dir="ltr" value={c.longitude ?? ''} onChange={set('longitude')} /></Field>
          <Field label="شعاع مجاز (متر)"><input type="number" min="20" dir="ltr" value={c.radius_m} onChange={set('radius_m')} /></Field>
        </div>
        <div className="row"><button type="button" className="btn sm" onClick={here}><Icon n="pin" size={15} /> استفاده از موقعیت فعلی من</button></div>
        <button className="btn primary">ذخیره تنظیمات</button>
      </form>
      <div className="card col"><h3>تعطیلات رسمی</h3>
        <form className="row wrap" style={{ alignItems: 'flex-end' }} onSubmit={addH}>
          <JalaliField label="تاریخ" value={h.date} onChange={(v) => setH({ ...h, date: v })} />
          <div className="grow" style={{ minWidth: 160 }}><Field label="عنوان"><input value={h.title} onChange={(e) => setH({ ...h, title: e.target.value })} /></Field></div>
          <button className="btn primary">افزودن</button></form>
        {hol.length === 0 ? <div className="muted">تعطیلی ثبت نشده است.</div> : <div className="col" style={{ gap: 6 }}>{hol.map((x) => (
          <div className="tl" key={x.id}><span>{jText(x.date)} {x.title && `· ${x.title}`}</span><button className="btn danger sm" onClick={() => api.delete(`/company/holidays/${x.id}/`).then(loadH)}>حذف</button></div>))}</div>}
      </div>
    </div>
  )
}
