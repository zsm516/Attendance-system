import { useState } from 'react'
import { useAuth } from '../auth'
import { api, errMsg, fa, mediaUrl } from '../lib'
import { Field } from '../components'

export default function Profile() {
  const { user, refreshMe } = useAuth()
  const [name, setName] = useState(user.full_name)
  const [pw, setPw] = useState({ old_password: '', new_password: '' })
  const [msg, setMsg] = useState(''), [err, setErr] = useState('')
  const flash = (m) => { setMsg(m); setErr(''); setTimeout(() => setMsg(''), 3000) }
  const save = async (e) => {
    e.preventDefault(); const fd = new FormData(); fd.append('full_name', name)
    const file = e.target.avatar?.files?.[0]; if (file) fd.append('avatar', file)
    try { await api.patch('/auth/me/', fd); await refreshMe(); flash('پروفایل ذخیره شد.') } catch (x) { setErr(errMsg(x)) }
  }
  const change = async (e) => { e.preventDefault(); try { await api.post('/auth/change-password/', pw); setPw({ old_password: '', new_password: '' }); flash('رمز عبور تغییر کرد.') } catch (x) { setErr(errMsg(x)) } }
  return (
    <div className="grid g2">
      <form className="card col" onSubmit={save}>
        <h3>پروفایل کاربری</h3>
        <div className="row"><div className="avatar" style={{ width: 64, height: 64, cursor: 'default' }}>{user.avatar ? <img src={mediaUrl(user.avatar)} alt="" /> : user.full_name?.[0]}</div>
          <div><b>{user.full_name}</b><div className="muted small" dir="ltr" style={{ textAlign: 'right' }}>{fa(user.phone)}</div></div></div>
        <Field label="نام و نام خانوادگی"><input value={name} onChange={(e) => setName(e.target.value)} required /></Field>
        <Field label="تصویر پروفایل"><input type="file" name="avatar" accept="image/*" /></Field>
        <button className="btn primary">ذخیره</button>
      </form>
      <form className="card col" onSubmit={change}>
        <h3>تغییر رمز عبور</h3>
        <Field label="رمز فعلی"><input type="password" dir="ltr" required value={pw.old_password} onChange={(e) => setPw({ ...pw, old_password: e.target.value })} /></Field>
        <Field label="رمز جدید (حداقل ۶ کاراکتر)"><input type="password" dir="ltr" required minLength={6} value={pw.new_password} onChange={(e) => setPw({ ...pw, new_password: e.target.value })} /></Field>
        <button className="btn">تغییر رمز</button>
      </form>
      {(msg || err) && <div className={msg ? 'okmsg' : 'err'} style={{ gridColumn: '1/-1' }}>{msg || err}</div>}
    </div>
  )
}
