import { useCallback, useEffect, useState } from 'react'
import { api, curJalali, errMsg, fa, mins, todayIso } from '../lib'
import { JalaliField, Modal, MonthNav, Spinner, StatusChip } from '../components'
import MonthView, { SummaryGrid } from './MonthView'

export default function Dashboard() {
  const [date, setDate] = useState(todayIso())
  const [q, setQ] = useState('')
  const [d, setD] = useState(null)
  const [err, setErr] = useState('')
  const [sel, setSel] = useState(null)
  const load = useCallback(() => api.get('/attendance/board/', { params: { date, q } }).then((r) => { setD(r.data); setErr('') }).catch((e) => setErr(errMsg(e))), [date, q])
  useEffect(() => { load(); const t = setInterval(load, 30000); return () => clearInterval(t) }, [load])
  const c = d?.counts || {}
  return (
    <div className="col" style={{ gap: 14 }}>
      <div className="row between wrap" style={{ alignItems: 'flex-end' }}>
        <div><h2>داشبورد حضور و غیاب</h2><div className="muted">{fa(d?.jalali_long)}</div></div>
        <div className="row wrap"><JalaliField label="تاریخ" value={date} onChange={setDate} /><button className="btn sm" onClick={() => setDate(todayIso())}>امروز</button></div>
      </div>
      <div className="grid g4">
        <div className="card stat"><b style={{ color: 'var(--ok)' }}>{fa(c.present || 0)}</b><span>حاضر</span></div>
        <div className="card stat"><b style={{ color: 'var(--bad)' }}>{fa(c.absent || 0)}</b><span>غایب</span></div>
        <div className="card stat"><b style={{ color: 'var(--warn)' }}>{fa(c.leave || 0)}</b><span>در مرخصی</span></div>
        <div className="card stat"><b>{fa(d?.total || 0)}</b><span>کل کارمندان فعال</span></div>
      </div>
      <div className="card">
        <div className="row between wrap" style={{ marginBottom: 10 }}><h3 style={{ margin: 0 }}>وضعیت کارمندان</h3><input style={{ maxWidth: 240 }} placeholder="جستجوی نام یا کد…" value={q} onChange={(e) => setQ(e.target.value)} /></div>
        {err && <div className="err">{err}</div>}
        {!d ? <Spinner /> : d.rows.length === 0 ? <div className="muted center" style={{ padding: 20 }}>هنوز کارمندی ثبت نشده است. از بخش «کارمندان» اضافه کنید.</div> : (
          <div className="tablewrap"><table>
            <thead><tr><th>کد</th><th>نام</th><th>وضعیت</th><th>ورود</th><th>خروج</th><th>کارکرد</th><th>تأخیر</th></tr></thead>
            <tbody>{d.rows.map((r) => (
              <tr key={r.id} className="click" onClick={() => setSel(r.id)}>
                <td className="num">{fa(r.code)}</td>
                <td><span className={`dot ${r.is_inside ? 'on' : ''}`} style={{ marginInlineEnd: 8 }} />{r.full_name}</td>
                <td><StatusChip s={r.status} /></td>
                <td className="num">{r.in_time ? fa(r.in_time) : '—'}</td><td className="num">{r.out_time ? fa(r.out_time) : '—'}</td>
                <td className="num">{mins(r.worked_minutes)}</td><td className="num">{r.late_minutes ? `${fa(r.late_minutes)} د` : '—'}</td>
              </tr>))}</tbody></table></div>
        )}
      </div>
      {sel && <EmployeeModal id={sel} onClose={() => setSel(null)} />}
    </div>
  )
}

function EmployeeModal({ id, onClose }) {
  const c = curJalali()
  const [ym, setYm] = useState([c.jy, c.jm])
  const [d, setD] = useState(null)
  useEffect(() => { setD(null); api.get(`/attendance/employee/${id}/`, { params: { year: ym[0], month: ym[1] } }).then((r) => setD(r.data)) }, [id, ym])
  const e = d?.employee
  const WD = ['دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه', 'شنبه', 'یکشنبه']
  return (
    <Modal title={e ? `${e.full_name} (${fa(e.code)})` : '…'} onClose={onClose}>
      {!d ? <Spinner /> : <div className="col">
        <div className="muted small">{e.employment_type === 'full' ? 'تمام‌وقت' : 'پاره‌وقت'} · {fa(e.weekly_hours)} ساعت در هفته {e.position && `· ${e.position}`}</div>
        <div className="row wrap" style={{ gap: 6 }}>{e.shifts.map((s) => <span key={s.weekday} className="chip holiday">{WD[s.weekday]} {fa(s.start)}–{fa(s.end)}</span>)}</div>
        <MonthNav year={ym[0]} month={ym[1]} onChange={(y, m) => setYm([y, m])} />
        <SummaryGrid s={d.summary} />
        <MonthView key={ym.join()} days={d.days} />
      </div>}
    </Modal>
  )
}
