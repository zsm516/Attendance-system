import { useEffect, useState } from 'react'
import { api, curJalali, errMsg, fa, mins } from '../lib'
import { Icon, MonthNav, Spinner } from '../components'

export default function Reports() {
  const c = curJalali()
  const [ym, setYm] = useState([c.jy, c.jm])
  const [d, setD] = useState(null)
  const [err, setErr] = useState('')
  useEffect(() => { setD(null); api.get('/reports/monthly/', { params: { year: ym[0], month: ym[1] } }).then((r) => setD(r.data)).catch((e) => setErr(errMsg(e))) }, [ym])
  const csv = async () => {
    try {
      const r = await api.get('/reports/monthly.csv', { params: { year: ym[0], month: ym[1] }, responseType: 'blob' })
      const a = document.createElement('a'); a.href = URL.createObjectURL(r.data); a.download = `attendance-${ym[0]}-${ym[1]}.csv`; a.click()
    } catch (e) { setErr(errMsg(e)) }
  }
  return (
    <div className="col" style={{ gap: 14 }}>
      <div className="row between wrap"><h2>گزارش ماهانه</h2><button className="btn" onClick={csv}><Icon n="dl" size={16} /> خروجی اکسل (CSV)</button></div>
      <div className="card"><MonthNav year={ym[0]} month={ym[1]} onChange={(y, m) => setYm([y, m])} /></div>
      {err && <div className="err">{err}</div>}
      <div className="card">{!d ? <Spinner /> : d.rows.length === 0 ? <div className="muted center">داده‌ای نیست.</div> :
        <div className="tablewrap"><table><thead><tr><th>کد</th><th>نام</th><th>حضور</th><th>غیبت</th><th>مرخصی</th><th>تعطیل</th><th>کارکرد</th><th>تأخیر (د)</th><th>تعجیل (د)</th></tr></thead>
          <tbody>{d.rows.map((r) => <tr key={r.id}><td className="num">{fa(r.code)}</td><td>{r.full_name}</td><td className="num">{fa(r.present)}</td>
            <td className="num" style={{ color: r.absent ? 'var(--bad)' : undefined }}>{fa(r.absent)}</td><td className="num">{fa(r.leave)}</td><td className="num">{fa(r.holiday)}</td>
            <td className="num">{mins(r.worked_minutes)}</td><td className="num">{fa(r.late_minutes)}</td><td className="num">{fa(r.early_leave_minutes)}</td></tr>)}</tbody></table></div>}</div>
    </div>
  )
}
