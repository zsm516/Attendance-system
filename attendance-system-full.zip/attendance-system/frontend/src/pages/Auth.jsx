import { useState } from 'react'
import { useAuth } from '../auth'
import { errMsg, getApiBase, isNative, setApiBase } from '../lib'
import { Field } from '../components'

export function Login() {
  const { login, registerCompany } = useAuth()
  const [tab, setTab] = useState('login')
  const [f, setF] = useState({ phone: '', password: '', full_name: '', national_id: '', company_name: '' })
  const [err, setErr] = useState('')
  const [busy, setBusy] = useState(false)
  const [server, setServer] = useState(localStorage.getItem('api_base') || '')
  const [showSrv, setShowSrv] = useState(isNative() && !localStorage.getItem('api_base'))
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value })

  const submit = async (e) => {
    e.preventDefault(); setErr(''); setBusy(true)
    try {
      if (tab === 'login') await login(f.phone, f.password)
      else await registerCompany({ full_name: f.full_name, phone: f.phone, national_id: f.national_id, company_name: f.company_name, password: f.password })
    } catch (x) { setErr(errMsg(x)) } finally { setBusy(false) }
  }
  const saveServer = () => { setApiBase(server.trim() ? server.trim().replace(/\/+$/, '').replace(/(\/api\/v1)?$/, '/api/v1') : ''); setShowSrv(false) }

  return (
    <div className="hero">
      <div className="auth col" style={{ gap: 16 }}>
        <div className="center">
          <div className="brand" style={{ justifyContent: 'center', fontSize: 22 }}><i>◷</i>سامانه حضور و غیاب</div>
          <div className="muted">ثبت آنلاین ورود و خروج، مرخصی و گزارش کارکرد</div>
        </div>
        <div className="card col">
          <div className="tabs">
            <button className={tab === 'login' ? 'on' : ''} onClick={() => { setTab('login'); setErr('') }}>ورود</button>
            <button className={tab === 'register' ? 'on' : ''} onClick={() => { setTab('register'); setErr('') }}>ثبت شرکت (مدیر)</button>
          </div>
          <form className="col" onSubmit={submit}>
            {tab === 'register' && <>
              <Field label="نام و نام خانوادگی"><input required value={f.full_name} onChange={set('full_name')} /></Field>
              <Field label="نام شرکت"><input required value={f.company_name} onChange={set('company_name')} /></Field>
              <Field label="کد ملی"><input required inputMode="numeric" dir="ltr" maxLength={10} value={f.national_id} onChange={set('national_id')} /></Field>
            </>}
            <Field label="شماره موبایل"><input required inputMode="tel" dir="ltr" placeholder="09123456789" value={f.phone} onChange={set('phone')} /></Field>
            <Field label="رمز عبور"><input required type="password" dir="ltr" minLength={tab === 'register' ? 6 : 1} value={f.password} onChange={set('password')} /></Field>
            {err && <div className="err">{err}</div>}
            <button className="btn primary block" disabled={busy}>{busy ? 'کمی صبر کنید…' : tab === 'login' ? 'ورود' : 'ساخت حساب و ورود'}</button>
          </form>
          {tab === 'login' && <div className="muted small center">کارمندان با شماره موبایلی که مدیر ثبت کرده وارد می‌شوند.</div>}
        </div>
        {(isNative() || showSrv) && (
          <div className="card col">
            <div className="row between"><b>آدرس سرور</b><button className="btn sm" onClick={() => setShowSrv(!showSrv)}>{showSrv ? 'بستن' : 'تغییر'}</button></div>
            {showSrv ? <>
              <input dir="ltr" placeholder="https://your-domain.com" value={server} onChange={(e) => setServer(e.target.value)} />
              <button className="btn primary" onClick={saveServer}>ذخیره</button>
            </> : <div className="muted small" dir="ltr" style={{ textAlign: 'left' }}>{getApiBase()}</div>}
          </div>
        )}
      </div>
    </div>
  )
}
