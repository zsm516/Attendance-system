import { useCallback, useEffect, useState } from 'react'
import { useAuth } from '../auth'
import { api, errMsg, fa, jText, todayIso } from '../lib'
import { Field, JalaliField, Modal, Spinner } from '../components'

const TYPES = [['daily', 'مرخصی روزانه'], ['hourly', 'مرخصی ساعتی'], ['sick', 'استعلاجی'], ['mission', 'ماموریت']]
const ST = { pending: 'در انتظار', approved: 'تأیید شده', rejected: 'رد شده' }

export default function Leaves() {
  const { user } = useAuth()
  const mgr = user.role === 'manager'
  const [list, setList] = useState(null)
  const [filter, setFilter] = useState(mgr ? 'pending' : '')
  const [show, setShow] = useState(false)
  const [err, setErr] = useState('')
  const load = useCallback(() => api.get('/leaves/', { params: filter ? { status: filter } : {} }).then((r) => setList(r.data.results)).catch((e) => setErr(errMsg(e))), [filter])
  useEffect(() => { load() }, [load])

  const review = async (id, act) => {
    const note = act === 'reject' ? prompt('دلیل رد (اختیاری):') || '' : ''
    try { await api.post(`/leaves/${id}/${act}/`, { note }); load() } catch (e) { setErr(errMsg(e)) }
  }
  const del = async (id) => { if (!confirm('درخواست حذف شود؟')) return; try { await api.delete(`/leaves/${id}/`); load() } catch (e) { setErr(errMsg(e)) } }

  return (
    <div className="col" style={{ gap: 14 }}>
      <div className="row between wrap">
        <div className="tabs" style={{ minWidth: 260 }}>
          {[['', 'همه'], ['pending', 'در انتظار'], ['approved', 'تأیید'], ['rejected', 'رد']].map(([k, t]) => <button key={k} className={filter === k ? 'on' : ''} onClick={() => setFilter(k)}>{t}</button>)}
        </div>
        {!mgr && <button className="btn primary" onClick={() => setShow(true)}>+ درخواست مرخصی</button>}
      </div>
      {err && <div className="err">{err}</div>}
      {!list ? <Spinner /> : list.length === 0 ? <div className="card muted center">درخواستی وجود ندارد.</div> : (
        <div className="col">{list.map((l) => (
          <div className="card" key={l.id}>
            <div className="row between wrap">
              <div><b>{mgr ? `${l.employee_name} (${fa(l.employee_code)}) · ` : ''}{l.type_label}</b>
                <div className="muted small">{l.start_date === l.end_date ? jText(l.start_date) : `${jText(l.start_date)} تا ${jText(l.end_date)}`}
                  {l.start_time && ` · ${fa(l.start_time.slice(0, 5))} تا ${fa(l.end_time.slice(0, 5))}`}</div></div>
              <span className={`chip ${l.status}`}>{ST[l.status]}</span>
            </div>
            {l.reason && <div style={{ marginTop: 8 }}>{l.reason}</div>}
            {l.review_note && <div className="muted small" style={{ marginTop: 6 }}>یادداشت مدیر: {l.review_note}</div>}
            <div className="row" style={{ marginTop: 10 }}>
              {mgr && l.status === 'pending' && <><button className="btn ok sm" onClick={() => review(l.id, 'approve')}>تأیید</button><button className="btn danger sm" onClick={() => review(l.id, 'reject')}>رد</button></>}
              {!mgr && l.status === 'pending' && <button className="btn danger sm" onClick={() => del(l.id)}>حذف</button>}
            </div>
          </div>))}</div>
      )}
      {show && <LeaveForm onClose={() => setShow(false)} onDone={() => { setShow(false); setFilter(''); load() }} />}
    </div>
  )
}

function LeaveForm({ onClose, onDone }) {
  const [f, setF] = useState({ leave_type: 'daily', start_date: todayIso(), end_date: todayIso(), start_time: '09:00', end_time: '11:00', reason: '' })
  const [err, setErr] = useState('')
  const [busy, setBusy] = useState(false)
  const hourly = f.leave_type === 'hourly'
  const submit = async (e) => {
    e.preventDefault(); setBusy(true); setErr('')
    const body = { ...f, end_date: hourly ? f.start_date : f.end_date }
    if (!hourly) { delete body.start_time; delete body.end_time }
    try { await api.post('/leaves/', body); onDone() } catch (x) { setErr(errMsg(x)) } finally { setBusy(false) }
  }
  return (
    <Modal title="درخواست مرخصی" onClose={onClose}>
      <form className="col" onSubmit={submit}>
        <Field label="نوع"><select value={f.leave_type} onChange={(e) => setF({ ...f, leave_type: e.target.value })}>{TYPES.map(([k, t]) => <option key={k} value={k}>{t}</option>)}</select></Field>
        <JalaliField label={hourly ? 'تاریخ' : 'از تاریخ'} value={f.start_date} onChange={(v) => setF({ ...f, start_date: v, end_date: v > f.end_date ? v : f.end_date })} />
        {!hourly && <JalaliField label="تا تاریخ" value={f.end_date} onChange={(v) => setF({ ...f, end_date: v })} />}
        {hourly && <div className="grid g2 keep"><Field label="از ساعت"><input type="time" dir="ltr" value={f.start_time} onChange={(e) => setF({ ...f, start_time: e.target.value })} /></Field>
          <Field label="تا ساعت"><input type="time" dir="ltr" value={f.end_time} onChange={(e) => setF({ ...f, end_time: e.target.value })} /></Field></div>}
        <Field label="توضیحات"><textarea rows={3} value={f.reason} onChange={(e) => setF({ ...f, reason: e.target.value })} /></Field>
        {err && <div className="err">{err}</div>}
        <button className="btn primary" disabled={busy}>ارسال برای مدیر</button>
      </form>
    </Modal>
  )
}
