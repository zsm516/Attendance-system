import { useEffect, useState } from 'react'
import { api, curJalali, errMsg } from '../lib'
import { MonthNav, Spinner } from '../components'
import MonthView, { SummaryGrid } from './MonthView'

export default function MyAttendance() {
  const c = curJalali()
  const [ym, setYm] = useState([c.jy, c.jm])
  const [d, setD] = useState(null)
  const [err, setErr] = useState('')
  useEffect(() => { setD(null); api.get('/attendance/my/', { params: { year: ym[0], month: ym[1] } }).then((r) => setD(r.data)).catch((e) => setErr(errMsg(e))) }, [ym])
  return (
    <div className="col" style={{ gap: 14 }}>
      <div className="card"><MonthNav year={ym[0]} month={ym[1]} onChange={(y, m) => setYm([y, m])} /></div>
      {err && <div className="err">{err}</div>}
      {!d ? <Spinner /> : <><SummaryGrid s={d.summary} /><div className="card"><MonthView key={ym.join()} days={d.days} /></div></>}
    </div>
  )
}
