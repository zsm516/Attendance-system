import { useState } from 'react'
import { fa, mins, STATUS, WEEK_ORDER, WEEKDAYS_PY, isoToJ, pyWeekday } from '../lib'
import { StatusChip } from '../components'

export function SummaryGrid({ s }) {
  return (
    <div className="grid g4">
      <div className="card stat"><b style={{ color: 'var(--ok)' }}>{fa(s.present)}</b><span>روز حضور</span></div>
      <div className="card stat"><b style={{ color: 'var(--bad)' }}>{fa(s.absent)}</b><span>غیبت</span></div>
      <div className="card stat"><b style={{ color: 'var(--warn)' }}>{fa(s.leave)}</b><span>مرخصی</span></div>
      <div className="card stat"><b>{fa(s.holiday)}</b><span>تعطیل</span></div>
      <div className="card stat"><b className="num">{mins(s.worked_minutes)}</b><span>ساعت کارکرد</span></div>
      <div className="card stat"><b className="num">{fa(s.late_minutes)}</b><span>دقیقه تأخیر</span></div>
    </div>
  )
}

export default function MonthView({ days }) {
  const [sel, setSel] = useState(null)
  const first = days.length ? pyWeekday(days[0].date) : 0
  const pad = WEEK_ORDER.indexOf(first)
  const cur = sel && days.find((d) => d.date === sel)
  return (
    <div className="col">
      <div className="cal">
        {WEEK_ORDER.map((w) => <div className="h" key={w}>{WEEKDAYS_PY[w].replace('‌', '')}</div>)}
        {Array.from({ length: pad }).map((_, i) => <div key={'p' + i} className="cell empty" />)}
        {days.map((d) => (
          <div key={d.date} className={`cell ${STATUS[d.status]?.c} ${sel === d.date ? 'sel' : ''}`} onClick={() => setSel(d.date)}>
            <span className="d">{fa(isoToJ(d.date).jd)}</span>
            <span className="mk" style={{ color: d.status === 'present' ? 'var(--ok)' : d.status === 'absent' || d.status === 'leave' ? 'var(--bad)' : 'var(--muted)' }}>{STATUS[d.status]?.mk}</span>
          </div>
        ))}
      </div>
      {cur && (
        <div className="card"><div className="row between"><b>{cur.weekday} {cur.jalali && fa(cur.jalali)}</b><StatusChip s={cur.status} /></div>
          <div className="muted small" style={{ marginTop: 6 }}>
            {cur.shift ? `شیفت: ${fa(cur.shift.start)} – ${fa(cur.shift.end)}` : 'شیفتی تعریف نشده'}
            {cur.holiday_title && ` · ${cur.holiday_title}`}{cur.leave_type && ` · ${cur.leave_type}`}</div>
          {cur.records.map((r) => <div className="tl" style={{ marginTop: 8 }} key={r.id}><span>ورود <b>{fa(r.in_time)}</b></span><span>خروج <b>{r.out_time ? fa(r.out_time) : '—'}</b></span><span className="muted small">{mins(r.worked_minutes)}</span></div>)}
        </div>
      )}
    </div>
  )
}
