import { useCallback, useEffect, useState } from 'react'
import { Geolocation } from '@capacitor/geolocation'
import { api, errMsg, fa, isNetworkError, mins, queue, uuid, flushQueue } from '../lib'
import { Icon, Spinner, StatusChip } from '../components'

async function getPos(required) {
  try {
    const p = await Geolocation.getCurrentPosition({ enableHighAccuracy: true, timeout: 12000 })
    return { lat: p.coords.latitude, lng: p.coords.longitude }
  } catch (e) {
    if (required) throw new Error('دریافت موقعیت مکانی ممکن نشد. GPS و مجوز دسترسی را فعال کنید.')
    return {}
  }
}

export default function EmployeeHome() {
  const [t, setT] = useState(null)
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState('')
  const [pend, setPend] = useState(queue.all())
  const [tick, setTick] = useState(Date.now())

  const load = useCallback(() => api.get('/attendance/today/').then((r) => { setT(r.data); setErr('') })
    .catch((e) => setErr(errMsg(e))), [])
  useEffect(() => { load(); setPend(queue.all()) }, [load])
  useEffect(() => { const h = () => { load(); setPend(queue.all()) }; window.addEventListener('attendance:synced', h); return () => window.removeEventListener('attendance:synced', h) }, [load])
  useEffect(() => { const i = setInterval(() => setTick(Date.now()), 30000); return () => clearInterval(i) }, [])

  if (!t) return err ? <div className="err">{err}</div> : <Spinner />
  const inside = pend.length ? pend[pend.length - 1].type === 'check_in' : t.is_checked_in

  const punch = async () => {
    setBusy(true); setErr('')
    const type = inside ? 'check_out' : 'check_in'
    const client_uuid = uuid()
    try {
      const pos = await getPos(t.require_location)
      try {
        const { data } = await api.post(`/attendance/${type === 'check_in' ? 'check-in' : 'check-out'}/`, { ...pos, client_uuid })
        setT(data)
      } catch (e) {
        if (!isNetworkError(e)) throw e
        queue.push({ type, time: new Date().toISOString(), client_uuid, ...pos }); setPend(queue.all())
      }
    } catch (e) { setErr(e.message && !e.response ? e.message : errMsg(e)) } finally { setBusy(false) }
  }
  const sync = async () => { setBusy(true); const r = await flushQueue(); setBusy(false); if (r) { setPend(queue.all()); load() } else setErr('همگام‌سازی انجام نشد؛ اتصال اینترنت را بررسی کنید.') }

  const liveMin = t.open_since ? Math.max(0, (tick - new Date(t.open_since).getTime()) / 60000) : 0
  return (
    <div className="col" style={{ gap: 16 }}>
      <div className="card">
        <div className="row between wrap"><div><h3 style={{ margin: 0 }}>{fa(t.jalali_long)}</h3>
          <div className="muted small">{t.shift ? `شیفت امروز: ${fa(t.shift.start)} تا ${fa(t.shift.end)}` : 'امروز شیفت ندارید'}</div></div>
          <StatusChip s={inside ? 'present' : t.status} /></div>
        <div className="punch">
          <button className={`big ${inside ? 'out' : ''}`} onClick={punch} disabled={busy}>{busy ? '…' : inside ? 'ثبت خروج' : 'ثبت ورود'}</button>
          <div className="muted small row"><span className={`dot ${inside ? 'on' : ''}`} />{inside ? 'در محل کار هستید' : 'خارج از محل کار'}
            {t.require_location && <span className="row" style={{ gap: 4 }}>· <Icon n="pin" size={14} />موقعیت مکانی ثبت می‌شود</span>}</div>
          {inside && t.open_since && <div className="muted small">مدت حضور فعلی: <b className="num">{mins(liveMin)}</b></div>}
        </div>
        {err && <div className="err">{err}</div>}
        {pend.length > 0 && <div className="banner row between wrap" style={{ marginTop: 10 }}><span>{fa(pend.length)} رویداد آفلاین در انتظار همگام‌سازی است.</span><button className="btn sm" onClick={sync} disabled={busy}>همگام‌سازی</button></div>}
      </div>
      <div className="grid g2 keep">
        <div className="card stat"><b className="num">{mins(t.worked_minutes + (inside ? liveMin : 0))}</b><span>کارکرد امروز (ساعت:دقیقه)</span></div>
        <div className="card stat"><b className="num">{fa(t.records.length)}</b><span>تعداد ورود امروز</span></div>
      </div>
      <div className="card"><h3>تردد امروز</h3>
        {t.records.length === 0 && pend.length === 0 && <div className="muted">هنوز تردی ثبت نشده است.</div>}
        <div className="timeline">
          {t.records.map((r) => <div className="tl" key={r.id}><span>ورود <b className="num">{fa(r.in_time)}</b></span><span>خروج <b className="num">{r.out_time ? fa(r.out_time) : '—'}</b></span>
            <span className="muted small">{r.late_minutes > 0 ? `${fa(r.late_minutes)} دقیقه تأخیر` : ''}</span></div>)}
          {pend.map((p) => <div className="tl" key={p.client_uuid} style={{ borderStyle: 'dashed' }}><span>{p.type === 'check_in' ? 'ورود' : 'خروج'} (آفلاین)</span><span className="num">{fa(new Date(p.time).toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' }))}</span></div>)}
        </div>
      </div>
    </div>
  )
}
