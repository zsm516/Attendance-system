import { useCallback, useEffect, useState } from 'react'
import { api, errMsg, fa, WEEK_ORDER, WEEKDAYS_PY } from '../lib'
import { Field, Modal, Spinner } from '../components'

const blank = () => ({ full_name: '', phone: '', national_id: '', password: '', code: '', position: '', employment_type: 'full', weekly_hours: 44, hired_at: '', is_active: true, shifts: [] })

export default function Employees() {
  const [list, setList] = useState(null)
  const [q, setQ] = useState('')
  const [edit, setEdit] = useState(null)
  const [err, setErr] = useState('')
  const load = useCallback(() => api.get('/employees/', { params: { q } }).then((r) => setList(r.data)).catch((e) => setErr(errMsg(e))), [q])
  useEffect(() => { load() }, [load])
  const del = async (e) => { if (!confirm(`حذف ${e.full_name}؟ تمام سوابق حضور او هم پاک می‌شود.`)) return; try { await api.delete(`/employees/${e.id}/`); load() } catch (x) { setErr(errMsg(x)) } }
  return (
    <div className="col" style={{ gap: 14 }}>
      <div className="row between wrap"><h2>کارمندان</h2>
        <div className="row"><input style={{ width: 220 }} placeholder="جستجو…" value={q} onChange={(e) => setQ(e.target.value)} /><button className="btn primary" onClick={() => setEdit(blank())}>+ کارمند جدید</button></div></div>
      {err && <div className="err">{err}</div>}
      <div className="card">{!list ? <Spinner /> : list.length === 0 ? <div className="muted center" style={{ padding: 20 }}>کارمندی ثبت نشده است.</div> :
        <div className="tablewrap"><table><thead><tr><th>کد</th><th>نام</th><th>موبایل</th><th>نوع</th><th>ساعت هفتگی</th><th>وضعیت</th><th /></tr></thead>
          <tbody>{list.map((e) => <tr key={e.id}><td className="num">{fa(e.code)}</td><td>{e.full_name}</td><td className="num" dir="ltr">{fa(e.phone)}</td>
            <td>{e.employment_type === 'full' ? 'تمام‌وقت' : 'پاره‌وقت'}</td><td className="num">{fa(e.weekly_hours)}</td>
            <td><span className={`chip ${e.is_active ? 'present' : 'absent'}`}>{e.is_active ? 'فعال' : 'غیرفعال'}</span></td>
            <td><div className="row"><button className="btn sm" onClick={() => setEdit({ ...e, password: '', hired_at: e.hired_at || '' })}>ویرایش</button><button className="btn danger sm" onClick={() => del(e)}>حذف</button></div></td></tr>)}</tbody></table></div>}</div>
      {edit && <EmployeeForm init={edit} onClose={() => setEdit(null)} onDone={() => { setEdit(null); load() }} />}
    </div>
  )
}

function EmployeeForm({ init, onClose, onDone }) {
  const isNew = !init.id
  const [f, setF] = useState(init)
  const [err, setErr] = useState('')
  const [busy, setBusy] = useState(false)
  const set = (k) => (e) => setF({ ...f, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value })
  const shiftOf = (w) => f.shifts.find((s) => s.weekday === w)
  const toggle = (w) => setF({ ...f, shifts: shiftOf(w) ? f.shifts.filter((s) => s.weekday !== w) : [...f.shifts, { weekday: w, start_time: '08:00', end_time: '16:00' }] })
  const upd = (w, k, v) => setF({ ...f, shifts: f.shifts.map((s) => (s.weekday === w ? { ...s, [k]: v } : s)) })
  const preset = () => setF({ ...f, shifts: [5, 6, 0, 1, 2].map((w) => ({ weekday: w, start_time: '08:00', end_time: '16:00' })) })
  const total = f.shifts.reduce((a, s) => { const [h1, m1] = s.start_time.slice(0, 5).split(':').map(Number), [h2, m2] = s.end_time.slice(0, 5).split(':').map(Number); return a + (h2 * 60 + m2 - h1 * 60 - m1) / 60 }, 0)

  const submit = async (e) => {
    e.preventDefault(); setBusy(true); setErr('')
    const body = { ...f, weekly_hours: f.weekly_hours || 0, hired_at: f.hired_at || null,
      shifts: f.shifts.map((s) => ({ weekday: s.weekday, start_time: s.start_time.slice(0, 5), end_time: s.end_time.slice(0, 5) })) }
    if (!body.password) delete body.password
    if (!body.code) delete body.code
    try { isNew ? await api.post('/employees/', body) : await api.patch(`/employees/${f.id}/`, body); onDone() } catch (x) { setErr(errMsg(x)) } finally { setBusy(false) }
  }
  return (
    <Modal title={isNew ? 'افزودن کارمند' : 'ویرایش کارمند'} onClose={onClose}>
      <form className="col" onSubmit={submit}>
        <div className="grid g2 keep">
          <Field label="نام و نام خانوادگی"><input required value={f.full_name} onChange={set('full_name')} /></Field>
          <Field label="شماره موبایل (نام کاربری)"><input required dir="ltr" inputMode="tel" value={f.phone} onChange={set('phone')} /></Field>
          <Field label={isNew ? 'رمز عبور' : 'رمز جدید (اختیاری)'}><input dir="ltr" type="text" required={isNew} minLength={6} value={f.password} onChange={set('password')} /></Field>
          <Field label="کد پرسنلی (خودکار اگر خالی)"><input dir="ltr" value={f.code} onChange={set('code')} /></Field>
          <Field label="سمت"><input value={f.position} onChange={set('position')} /></Field>
          <Field label="نوع همکاری"><select value={f.employment_type} onChange={set('employment_type')}><option value="full">تمام‌وقت</option><option value="part">پاره‌وقت</option></select></Field>
          <Field label="ساعت کار هفتگی"><input type="number" step="0.5" min="0" dir="ltr" value={f.weekly_hours} onChange={set('weekly_hours')} /></Field>
          <Field label="تاریخ شروع به کار (میلادی)"><input type="date" dir="ltr" value={f.hired_at} onChange={set('hired_at')} /></Field>
        </div>
        <div className="row between"><b>برنامه شیفت هفتگی</b><button type="button" className="btn sm" onClick={preset}>شنبه تا چهارشنبه ۸ تا ۱۶</button></div>
        <div className="col" style={{ gap: 8 }}>{WEEK_ORDER.map((w) => { const s = shiftOf(w); return (
          <div className="shiftrow" key={w}>
            <label className="row" style={{ gap: 6 }}><input type="checkbox" checked={!!s} onChange={() => toggle(w)} />{WEEKDAYS_PY[w]}</label>
            {s ? <><input type="time" dir="ltr" value={s.start_time.slice(0, 5)} onChange={(e) => upd(w, 'start_time', e.target.value)} /><input type="time" dir="ltr" value={s.end_time.slice(0, 5)} onChange={(e) => upd(w, 'end_time', e.target.value)} /></> : <span className="muted small" style={{ gridColumn: 'span 2' }}>روز استراحت</span>}
          </div>) })}</div>
        <div className="muted small">مجموع شیفت‌های تعریف‌شده: {fa(total.toFixed(1))} ساعت در هفته</div>
        {!isNew && <label className="row"><input type="checkbox" checked={f.is_active} onChange={set('is_active')} />حساب فعال باشد</label>}
        {err && <div className="err">{err}</div>}
        <button className="btn primary" disabled={busy}>ذخیره</button>
      </form>
    </Modal>
  )
}
