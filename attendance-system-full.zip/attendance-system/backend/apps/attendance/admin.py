from django.contrib import admin
from .models import AttendanceRecord


@admin.register(AttendanceRecord)
class AttendanceAdmin(admin.ModelAdmin):
    list_display = ("employee", "date", "check_in", "check_out", "method", "late_minutes", "early_leave_minutes")
    list_filter = ("method", "date", "employee__company")
    search_fields = ("employee__user__full_name", "employee__code")
    date_hierarchy = "date"
