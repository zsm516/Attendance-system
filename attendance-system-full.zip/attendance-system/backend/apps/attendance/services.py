import datetime as dt
import math
from django.apps import apps
from django.utils import timezone
from rest_framework.exceptions import ValidationError
from apps.core.jalali import jalali_str, WEEKDAYS
from .models import AttendanceRecord


def haversine_m(lat1, lng1, lat2, lng2):
    R = 6371000.0
    p1, p2 = math.radians(float(lat1)), math.radians(float(lat2))
    dphi = p2 - p1
    dl = math.radians(float(lng2) - float(lng1))
    a = math.sin(dphi / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * R * math.asin(math.sqrt(a))


def _local(dtm):
    return timezone.localtime(dtm) if dtm else None


def _hhmm(dtm):
    return _local(dtm).strftime("%H:%M") if dtm else None


def validate_location(company, lat, lng):
    if not company.require_location:
        return
    if lat is None or lng is None:
        raise ValidationError("ثبت موقعیت مکانی الزامی است. دسترسی به GPS را فعال کنید.")
    if company.latitude is None:
        return
    dist = haversine_m(lat, lng, company.latitude, company.longitude)
    if dist > company.radius_m:
        raise ValidationError(f"شما خارج از محدوده مجاز شرکت هستید ({int(dist)} متر از محل).")


def _combine(d, t):
    return timezone.make_aware(dt.datetime.combine(d, t))


def check_in(employee, when=None, lat=None, lng=None, method="web", uuid=None):
    when = when or timezone.now()
    if uuid:
        ex = AttendanceRecord.objects.filter(in_uuid=uuid).first()
        if ex:
            return ex, False
    validate_location(employee.company, lat, lng)
    if AttendanceRecord.objects.filter(employee=employee, check_out__isnull=True).exists():
        raise ValidationError("ورود قبلی شما هنوز بسته نشده است؛ ابتدا خروج بزنید.")
    local = _local(when)
    d = local.date()
    late = 0
    first_of_day = not AttendanceRecord.objects.filter(employee=employee, date=d).exists()
    shift = employee.shift_for(d)
    if first_of_day and shift:
        start = _combine(d, shift.start_time)
        diff = int((when - start).total_seconds() // 60)
        if diff > employee.company.grace_minutes:
            late = diff
    rec = AttendanceRecord.objects.create(employee=employee, date=d, check_in=when, in_lat=lat, in_lng=lng,
                                          method=method, late_minutes=late, in_uuid=uuid or None)
    return rec, True


def check_out(employee, when=None, lat=None, lng=None, method="web", uuid=None):
    when = when or timezone.now()
    if uuid:
        ex = AttendanceRecord.objects.filter(out_uuid=uuid).first()
        if ex:
            return ex, False
    validate_location(employee.company, lat, lng)
    rec = AttendanceRecord.objects.filter(employee=employee, check_out__isnull=True).order_by("-check_in").first()
    if not rec:
        raise ValidationError("ورود فعالی برای ثبت خروج وجود ندارد.")
    if when <= rec.check_in:
        raise ValidationError("زمان خروج باید بعد از ورود باشد.")
    shift = employee.shift_for(rec.date)
    early = 0
    if shift:
        end = _combine(rec.date, shift.end_time)
        if when < end:
            early = int((end - when).total_seconds() // 60)
    rec.check_out, rec.out_lat, rec.out_lng, rec.early_leave_minutes = when, lat, lng, early
    rec.out_uuid = uuid or None
    rec.save()
    return rec, True


def serialize_record(r):
    return {"id": r.id, "date": r.date, "check_in": r.check_in, "check_out": r.check_out,
            "in_time": _hhmm(r.check_in), "out_time": _hhmm(r.check_out), "method": r.method,
            "late_minutes": r.late_minutes, "early_leave_minutes": r.early_leave_minutes,
            "worked_minutes": r.worked_minutes, "note": r.note}


def build_days(employee, start, end, today=None):
    """Per-day status list for one employee over [start, end]."""
    today = today or timezone.localdate()
    company = employee.company
    LeaveRequest = apps.get_model("leaves", "LeaveRequest")
    recs = {}
    for r in AttendanceRecord.objects.filter(employee=employee, date__range=(start, end)).order_by("check_in"):
        recs.setdefault(r.date, []).append(r)
    leaves = list(LeaveRequest.objects.filter(employee=employee, status="approved",
                                              start_date__lte=end, end_date__gte=start))
    hol = {h.date: h.title for h in company.holidays.filter(date__range=(start, end))}
    shifts = {s.weekday: s for s in employee.shifts.all()}
    out, d = [], start
    while d <= end:
        rs = recs.get(d, [])
        leave = next((l for l in leaves if l.start_date <= d <= l.end_date), None)
        shift = shifts.get(d.weekday())
        worked = sum(r.worked_minutes for r in rs)
        if d < (employee.hired_at or dt.date.min):
            status = "off"
        elif rs:
            status = "present"
        elif leave and leave.leave_type != "hourly":
            status = "leave"
        elif d in hol or d.weekday() in (company.weekend_days or []):
            status = "holiday"
        elif not shift:
            status = "off"
        elif d > today:
            status = "future"
        elif d == today and timezone.localtime().time() < shift.end_time:
            status = "pending"
        else:
            status = "absent"
        out.append({
            "date": d, "jalali": jalali_str(d), "weekday": WEEKDAYS[d.weekday()], "status": status,
            "holiday_title": hol.get(d, ""), "leave_type": leave.get_leave_type_display() if leave else None,
            "shift": {"start": shift.start_time.strftime("%H:%M"), "end": shift.end_time.strftime("%H:%M")} if shift else None,
            "in_time": _hhmm(rs[0].check_in) if rs else None,
            "out_time": _hhmm(rs[-1].check_out) if rs else None,
            "worked_minutes": worked, "late_minutes": rs[0].late_minutes if rs else 0,
            "early_leave_minutes": rs[-1].early_leave_minutes if rs else 0,
            "records": [serialize_record(r) for r in rs],
        })
        d += dt.timedelta(days=1)
    return out


def summarize(days):
    s = {"present": 0, "absent": 0, "leave": 0, "holiday": 0, "worked_minutes": 0, "late_minutes": 0, "early_leave_minutes": 0}
    for x in days:
        if x["status"] in ("present", "absent", "leave", "holiday"):
            s[x["status"]] += 1
        s["worked_minutes"] += x["worked_minutes"]
        s["late_minutes"] += x["late_minutes"]
        s["early_leave_minutes"] += x["early_leave_minutes"]
    return s
