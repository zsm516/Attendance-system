from django.urls import path
from . import views

urlpatterns = [
    path("today/", views.TodayView.as_view()),
    path("check-in/", views.CheckInView.as_view()),
    path("check-out/", views.CheckOutView.as_view()),
    path("sync/", views.SyncView.as_view()),
    path("my/", views.MyAttendanceView.as_view()),
    path("board/", views.BoardView.as_view()),
    path("employee/<int:pk>/", views.EmployeeDetailView.as_view()),
    path("manual/", views.ManualEntryView.as_view()),
    path("records/<int:pk>/", views.RecordDeleteView.as_view()),
]
