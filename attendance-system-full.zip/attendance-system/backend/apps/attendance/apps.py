from django.apps import AppConfig
class AttendanceConfig(AppConfig):
    name = "apps.attendance"
    label = "attendance"
    verbose_name = "حضور و غیاب"
