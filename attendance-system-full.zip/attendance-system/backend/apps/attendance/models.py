from django.db import models


class AttendanceRecord(models.Model):
    class Method(models.TextChoices):
        WEB = "web", "وب"
        MOBILE = "mobile", "موبایل"
        MANUAL = "manual", "دستی (مدیر)"

    employee = models.ForeignKey("employees.Employee", on_delete=models.CASCADE, related_name="records")
    date = models.DateField("تاریخ", db_index=True)
    check_in = models.DateTimeField("ورود")
    check_out = models.DateTimeField("خروج", null=True, blank=True)
    in_lat = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    in_lng = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    out_lat = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    out_lng = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    method = models.CharField("روش ثبت", max_length=10, choices=Method.choices, default=Method.WEB)
    late_minutes = models.PositiveIntegerField("تأخیر (دقیقه)", default=0)
    early_leave_minutes = models.PositiveIntegerField("تعجیل (دقیقه)", default=0)
    note = models.CharField("یادداشت", max_length=250, blank=True)
    in_uuid = models.CharField(max_length=64, null=True, blank=True, unique=True)
    out_uuid = models.CharField(max_length=64, null=True, blank=True, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "رکورد حضور"
        verbose_name_plural = "رکوردهای حضور"
        ordering = ["-check_in"]
        indexes = [models.Index(fields=["employee", "date"])]

    def __str__(self):
        return f"{self.employee} {self.date}"

    @property
    def worked_minutes(self):
        if not self.check_out:
            return 0
        return max(0, int((self.check_out - self.check_in).total_seconds() // 60))
