import datetime as dt
from django.db.models import Q
from django.utils import timezone
from django.utils.dateparse import parse_date, parse_datetime
from rest_framework.exceptions import ValidationError, NotFound
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.core.jalali import jalali_long, jalali_month_range, current_jalali_month
from apps.core.permissions import IsEmployee, IsManager
from apps.employees.models import Employee
from . import services as svc
from .models import AttendanceRecord


def _coords(data):
    def f(k):
        v = data.get(k)
        try:
            return round(float(v), 6) if v not in (None, "") else None
        except (TypeError, ValueError):
            raise ValidationError("مختصات نامعتبر است.")
    return f("lat"), f("lng")


def _method(request):
    return "mobile" if request.headers.get("X-Client") == "mobile" else "web"


def _month_range(request):
    try:
        jy = int(request.query_params.get("year") or 0)
        jm = int(request.query_params.get("month") or 0)
    except ValueError:
        raise ValidationError("سال/ماه نامعتبر است.")
    if not jy or not jm:
        jy, jm = current_jalali_month()
    if not 1 <= jm <= 12:
        raise ValidationError("ماه نامعتبر است.")
    first, last = jalali_month_range(jy, jm)
    return jy, jm, first, last


def _today_payload(emp):
    d = timezone.localdate()
    days = svc.build_days(emp, d, d)[0]
    open_rec = AttendanceRecord.objects.filter(employee=emp, check_out__isnull=True).first()
    return {"date": d, "jalali_long": jalali_long(d), "now": timezone.now(), "status": days["status"],
            "shift": days["shift"], "records": days["records"], "worked_minutes": days["worked_minutes"],
            "is_checked_in": bool(open_rec), "open_since": open_rec.check_in if open_rec else None,
            "require_location": emp.company.require_location}


class TodayView(APIView):
    permission_classes = [IsEmployee]

    def get(self, request):
        return Response(_today_payload(request.user.employee_profile))


class CheckInView(APIView):
    permission_classes = [IsEmployee]

    def post(self, request):
        emp = request.user.employee_profile
        lat, lng = _coords(request.data)
        svc.check_in(emp, lat=lat, lng=lng, method=_method(request), uuid=request.data.get("client_uuid"))
        return Response(_today_payload(emp), status=201)


class CheckOutView(APIView):
    permission_classes = [IsEmployee]

    def post(self, request):
        emp = request.user.employee_profile
        lat, lng = _coords(request.data)
        svc.check_out(emp, lat=lat, lng=lng, method=_method(request), uuid=request.data.get("client_uuid"))
        return Response(_today_payload(emp))


class SyncView(APIView):
    """Batch upload of punches recorded offline by the mobile app (idempotent via client_uuid)."""
    permission_classes = [IsEmployee]

    def post(self, request):
        emp = request.user.employee_profile
        items = request.data.get("events") or []
        if not isinstance(items, list) or len(items) > 200:
            raise ValidationError("فرمت رویدادها نامعتبر است.")
        now = timezone.now()
        parsed = []
        for it in items:
            t = parse_datetime(str(it.get("time", "")))
            parsed.append((t, it))
        parsed.sort(key=lambda x: x[0] or now)
        results = []
        for t, it in parsed:
            uid = it.get("client_uuid")
            res = {"client_uuid": uid, "type": it.get("type")}
            try:
                if not t or not uid:
                    raise ValidationError("زمان یا شناسه رویداد نامعتبر است.")
                if timezone.is_naive(t):
                    t = timezone.make_aware(t)
                if t > now + dt.timedelta(minutes=5) or t < now - dt.timedelta(days=3):
                    raise ValidationError("زمان رویداد خارج از بازه مجاز همگام‌سازی است.")
                lat, lng = _coords(it)
                fn = svc.check_in if it.get("type") == "check_in" else svc.check_out
                if it.get("type") not in ("check_in", "check_out"):
                    raise ValidationError("نوع رویداد نامعتبر است.")
                _, created = fn(emp, when=t, lat=lat, lng=lng, method="mobile", uuid=uid)
                res.update(ok=True, duplicate=not created)
            except ValidationError as e:
                res.update(ok=False, error=str(e.detail[0] if isinstance(e.detail, list) else e.detail))
            results.append(res)
        return Response({"results": results, "today": _today_payload(emp)})


class MyAttendanceView(APIView):
    permission_classes = [IsEmployee]

    def get(self, request):
        emp = request.user.employee_profile
        jy, jm, first, last = _month_range(request)
        days = svc.build_days(emp, first, last)
        return Response({"year": jy, "month": jm, "days": days, "summary": svc.summarize(days)})


class BoardView(APIView):
    """Manager live board: everyone's status for a given day."""
    permission_classes = [IsManager]

    def get(self, request):
        d = parse_date(request.query_params.get("date") or "") or timezone.localdate()
        company = request.user.company
        rows = []
        emps = Employee.objects.filter(company=company, is_active=True).select_related("user").prefetch_related("shifts")
        q = request.query_params.get("q")
        if q:
            emps = emps.filter(Q(user__full_name__icontains=q) | Q(code__icontains=q))
        counts = {"present": 0, "absent": 0, "leave": 0, "holiday": 0, "pending": 0, "off": 0, "future": 0}
        open_ids = set(AttendanceRecord.objects.filter(employee__company=company, check_out__isnull=True)
                       .values_list("employee_id", flat=True))
        for e in emps:
            day = svc.build_days(e, d, d)[0]
            counts[day["status"]] = counts.get(day["status"], 0) + 1
            rows.append({"id": e.id, "code": e.code, "full_name": e.user.full_name, "position": e.position,
                         "employment_type": e.employment_type, "status": day["status"], "in_time": day["in_time"],
                         "out_time": day["out_time"], "worked_minutes": day["worked_minutes"],
                         "late_minutes": day["late_minutes"], "shift": day["shift"],
                         "is_inside": e.id in open_ids})
        return Response({"date": d, "jalali_long": jalali_long(d), "counts": counts, "total": len(rows), "rows": rows})


class EmployeeDetailView(APIView):
    permission_classes = [IsManager]

    def get(self, request, pk):
        try:
            e = Employee.objects.select_related("user").prefetch_related("shifts").get(pk=pk, company=request.user.company)
        except Employee.DoesNotExist:
            raise NotFound("کارمند یافت نشد.")
        jy, jm, first, last = _month_range(request)
        days = svc.build_days(e, first, last)
        return Response({
            "employee": {"id": e.id, "code": e.code, "full_name": e.user.full_name, "phone": e.user.phone,
                         "position": e.position, "employment_type": e.employment_type,
                         "weekly_hours": e.weekly_hours,
                         "shifts": [{"weekday": s.weekday, "start": s.start_time.strftime("%H:%M"),
                                     "end": s.end_time.strftime("%H:%M")} for s in e.shifts.all()]},
            "year": jy, "month": jm, "days": days, "summary": svc.summarize(days)})


class ManualEntryView(APIView):
    permission_classes = [IsManager]

    def post(self, request):
        try:
            e = Employee.objects.get(pk=request.data.get("employee"), company=request.user.company)
        except (Employee.DoesNotExist, ValueError, TypeError):
            raise NotFound("کارمند یافت نشد.")
        d = parse_date(str(request.data.get("date", "")))
        t_in, t_out = parse_datetime(str(request.data.get("check_in", ""))), parse_datetime(str(request.data.get("check_out", "") or ""))
        if not d or not t_in:
            raise ValidationError("تاریخ و ساعت ورود الزامی است.")
        t_in = timezone.make_aware(t_in) if timezone.is_naive(t_in) else t_in
        if t_out:
            t_out = timezone.make_aware(t_out) if timezone.is_naive(t_out) else t_out
            if t_out <= t_in:
                raise ValidationError("ساعت خروج باید بعد از ورود باشد.")
        r = AttendanceRecord.objects.create(employee=e, date=d, check_in=t_in, check_out=t_out,
                                            method="manual", note=str(request.data.get("note", ""))[:250])
        return Response(svc.serialize_record(r), status=201)


class RecordDeleteView(APIView):
    permission_classes = [IsManager]

    def delete(self, request, pk):
        n, _ = AttendanceRecord.objects.filter(pk=pk, employee__company=request.user.company).delete()
        if not n:
            raise NotFound("رکورد یافت نشد.")
        return Response(status=204)
