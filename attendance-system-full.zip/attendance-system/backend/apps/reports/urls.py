from django.urls import path
from . import views

urlpatterns = [
    path("monthly/", views.MonthlyReportView.as_view()),
    path("monthly.csv", views.MonthlyCsvView.as_view()),
]
