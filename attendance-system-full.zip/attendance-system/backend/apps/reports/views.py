import csv
from django.http import HttpResponse
from rest_framework.exceptions import ValidationError
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.attendance import services as svc
from apps.core.jalali import jalali_month_range, current_jalali_month, MONTHS
from apps.core.permissions import IsManager
from apps.employees.models import Employee


def _rows(request):
    try:
        jy = int(request.query_params.get("year") or 0)
        jm = int(request.query_params.get("month") or 0)
    except ValueError:
        raise ValidationError("سال/ماه نامعتبر است.")
    if not jy or not jm:
        jy, jm = current_jalali_month()
    if not 1 <= jm <= 12:
        raise ValidationError("ماه نامعتبر است.")
    first, last = jalali_month_range(jy, jm)
    emps = Employee.objects.filter(company=request.user.company).select_related("user").prefetch_related("shifts")
    rows = []
    for e in emps:
        s = svc.summarize(svc.build_days(e, first, last))
        rows.append({"id": e.id, "code": e.code, "full_name": e.user.full_name,
                     "employment_type": e.get_employment_type_display(), **s})
    return jy, jm, rows


class MonthlyReportView(APIView):
    permission_classes = [IsManager]

    def get(self, request):
        jy, jm, rows = _rows(request)
        return Response({"year": jy, "month": jm, "month_name": MONTHS[jm - 1], "rows": rows})


class MonthlyCsvView(APIView):
    permission_classes = [IsManager]

    def get(self, request):
        jy, jm, rows = _rows(request)
        resp = HttpResponse(content_type="text/csv; charset=utf-8")
        resp["Content-Disposition"] = f'attachment; filename="attendance-{jy}-{jm:02d}.csv"'
        resp.write("\ufeff")
        w = csv.writer(resp)
        w.writerow(["کد", "نام", "نوع همکاری", "روز حضور", "غیبت", "مرخصی", "تعطیل", "ساعت کارکرد", "تأخیر (دقیقه)", "تعجیل (دقیقه)"])
        for r in rows:
            w.writerow([r["code"], r["full_name"], r["employment_type"], r["present"], r["absent"], r["leave"],
                        r["holiday"], round(r["worked_minutes"] / 60, 1), r["late_minutes"], r["early_leave_minutes"]])
        return resp
