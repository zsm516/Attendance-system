from django.conf import settings
from django.db import models


class Employee(models.Model):
    class Type(models.TextChoices):
        FULL = "full", "تمام‌وقت"
        PART = "part", "پاره‌وقت"

    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="employee_profile",
                                verbose_name="کاربر")
    company = models.ForeignKey("companies.Company", on_delete=models.CASCADE, related_name="employees",
                                verbose_name="شرکت")
    code = models.CharField("کد پرسنلی", max_length=20)
    position = models.CharField("سمت", max_length=100, blank=True)
    employment_type = models.CharField("نوع همکاری", max_length=5, choices=Type.choices, default=Type.FULL)
    weekly_hours = models.DecimalField("ساعت کار هفتگی", max_digits=5, decimal_places=1, default=44)
    hired_at = models.DateField("تاریخ استخدام", null=True, blank=True)
    is_active = models.BooleanField("فعال", default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "کارمند"
        verbose_name_plural = "کارمندان"
        unique_together = ("company", "code")
        ordering = ["code"]

    def __str__(self):
        return f"{self.code} – {self.user.full_name}"

    def shift_for(self, d):
        return self.shifts.filter(weekday=d.weekday()).first()


class WorkShift(models.Model):
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE, related_name="shifts")
    weekday = models.PositiveSmallIntegerField("روز هفته", help_text="دوشنبه=۰ ... یکشنبه=۶")
    start_time = models.TimeField("شروع")
    end_time = models.TimeField("پایان")

    class Meta:
        verbose_name = "شیفت"
        verbose_name_plural = "شیفت‌ها"
        unique_together = ("employee", "weekday")
        ordering = ["weekday"]

    def __str__(self):
        return f"{self.employee.code} d{self.weekday} {self.start_time}-{self.end_time}"
