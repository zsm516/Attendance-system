from django.db import transaction
from rest_framework import serializers
from apps.accounts.models import User
from apps.core.utils import normalize_digits, normalize_phone, PHONE_RE
from .models import Employee, WorkShift


class ShiftSerializer(serializers.ModelSerializer):
    class Meta:
        model = WorkShift
        fields = ["weekday", "start_time", "end_time"]

    def validate(self, a):
        if a["end_time"] <= a["start_time"]:
            raise serializers.ValidationError("ساعت پایان باید بعد از شروع باشد.")
        if not 0 <= a["weekday"] <= 6:
            raise serializers.ValidationError("روز هفته نامعتبر است.")
        return a


class EmployeeSerializer(serializers.ModelSerializer):
    full_name = serializers.CharField(source="user.full_name")
    phone = serializers.CharField(source="user.phone")
    national_id = serializers.CharField(source="user.national_id", required=False, allow_blank=True)
    password = serializers.CharField(write_only=True, required=False, min_length=6)
    shifts = ShiftSerializer(many=True, required=False)
    code = serializers.CharField(required=False)

    class Meta:
        model = Employee
        fields = ["id", "full_name", "phone", "national_id", "password", "code", "position", "employment_type",
                  "weekly_hours", "hired_at", "is_active", "shifts"]

    def validate_phone(self, v):
        v = normalize_phone(v)
        if not PHONE_RE.match(v):
            raise serializers.ValidationError("شماره موبایل معتبر نیست.")
        qs = User.objects.filter(phone=v)
        if self.instance:
            qs = qs.exclude(pk=self.instance.user_id)
        if qs.exists():
            raise serializers.ValidationError("این شماره قبلاً ثبت شده است.")
        return v

    def validate_code(self, v):
        v = normalize_digits(v)
        qs = Employee.objects.filter(company=self.context["company"], code=v)
        if self.instance:
            qs = qs.exclude(pk=self.instance.pk)
        if qs.exists():
            raise serializers.ValidationError("این کد پرسنلی تکراری است.")
        return v

    def validate(self, a):
        if not self.instance and "password" not in a:
            raise serializers.ValidationError({"password": "رمز عبور الزامی است."})
        return a

    def _next_code(self, company):
        nums = [int(c) for c in Employee.objects.filter(company=company).values_list("code", flat=True) if c.isdigit()]
        return str(max(nums, default=1000) + 1)

    def _set_shifts(self, emp, shifts):
        emp.shifts.all().delete()
        WorkShift.objects.bulk_create([WorkShift(employee=emp, **s) for s in shifts])

    @transaction.atomic
    def create(self, v):
        company = self.context["company"]
        u = v.pop("user")
        shifts = v.pop("shifts", [])
        password = v.pop("password")
        user = User.objects.create_user(username=u["phone"], phone=u["phone"], password=password,
                                        full_name=u["full_name"], national_id=u.get("national_id", ""),
                                        role=User.Role.EMPLOYEE)
        code = v.pop("code", None) or self._next_code(company)
        emp = Employee.objects.create(user=user, company=company, code=code, **v)
        self._set_shifts(emp, shifts)
        return emp

    @transaction.atomic
    def update(self, inst, v):
        u = v.pop("user", {})
        shifts = v.pop("shifts", None)
        password = v.pop("password", None)
        for k, val in u.items():
            setattr(inst.user, k, val)
        if "phone" in u:
            inst.user.username = u["phone"]
        if password:
            inst.user.set_password(password)
        if "is_active" in v:
            inst.user.is_active = v["is_active"]
        inst.user.save()
        for k, val in v.items():
            setattr(inst, k, val)
        inst.save()
        if shifts is not None:
            self._set_shifts(inst, shifts)
        return inst
