from django.contrib import admin
from .models import Employee, WorkShift


class ShiftInline(admin.TabularInline):
    model = WorkShift
    extra = 0


@admin.register(Employee)
class EmployeeAdmin(admin.ModelAdmin):
    list_display = ("code", "user", "company", "employment_type", "weekly_hours", "is_active")
    list_filter = ("company", "employment_type", "is_active")
    search_fields = ("code", "user__full_name", "user__phone")
    inlines = [ShiftInline]
