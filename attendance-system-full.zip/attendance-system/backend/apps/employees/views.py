from rest_framework import viewsets
from apps.core.permissions import IsManager
from .models import Employee
from .serializers import EmployeeSerializer


class EmployeeViewSet(viewsets.ModelViewSet):
    serializer_class = EmployeeSerializer
    permission_classes = [IsManager]
    pagination_class = None

    def get_queryset(self):
        qs = Employee.objects.filter(company=self.request.user.company).select_related("user").prefetch_related("shifts")
        q = self.request.query_params.get("q")
        if q:
            from django.db.models import Q
            qs = qs.filter(Q(user__full_name__icontains=q) | Q(code__icontains=q) | Q(user__phone__icontains=q))
        return qs

    def get_serializer_context(self):
        return {**super().get_serializer_context(), "company": self.request.user.company}

    def perform_destroy(self, inst):
        user = inst.user
        inst.delete()
        user.delete()
