from rest_framework import permissions, status
from rest_framework.parsers import FormParser, JSONParser, MultiPartParser
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.tokens import RefreshToken
from . import serializers as s


def _tokens(user):
    r = RefreshToken.for_user(user)
    return {"access": str(r.access_token), "refresh": str(r)}


class RegisterCompanyView(APIView):
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        ser = s.RegisterCompanySerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        user = ser.save()
        return Response({**_tokens(user), "user": s.UserSerializer(user, context={"request": request}).data},
                        status=status.HTTP_201_CREATED)


class LoginView(APIView):
    permission_classes = [permissions.AllowAny]
    throttle_scope = "login"

    def post(self, request):
        ser = s.LoginSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        user = ser.validated_data["user"]
        return Response({**_tokens(user), "user": s.UserSerializer(user, context={"request": request}).data})


class MeView(APIView):
    parser_classes = [JSONParser, MultiPartParser, FormParser]

    def get(self, request):
        return Response(s.UserSerializer(request.user, context={"request": request}).data)

    def patch(self, request):
        ser = s.ProfileUpdateSerializer(request.user, data=request.data, partial=True)
        ser.is_valid(raise_exception=True)
        ser.save()
        return Response(s.UserSerializer(request.user, context={"request": request}).data)


class ChangePasswordView(APIView):
    def post(self, request):
        ser = s.ChangePasswordSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        if not request.user.check_password(ser.validated_data["old_password"]):
            return Response({"detail": "رمز فعلی اشتباه است."}, status=400)
        request.user.set_password(ser.validated_data["new_password"])
        request.user.save()
        return Response({"detail": "رمز عبور تغییر کرد."})
