from django.apps import apps
from django.contrib.auth import authenticate
from django.db import transaction
from rest_framework import serializers
from apps.core.utils import normalize_digits, normalize_phone, PHONE_RE
from .models import User


def _phone(v):
    v = normalize_phone(v)
    if not PHONE_RE.match(v):
        raise serializers.ValidationError("شماره موبایل معتبر نیست (مثال: 09123456789).")
    return v


class UserSerializer(serializers.ModelSerializer):
    company_name = serializers.SerializerMethodField()
    employee_id = serializers.SerializerMethodField()
    avatar = serializers.ImageField(read_only=True)

    class Meta:
        model = User
        fields = ["id", "full_name", "phone", "national_id", "role", "avatar", "company_name", "employee_id"]
        read_only_fields = ["id", "phone", "role", "national_id"]

    def get_company_name(self, u):
        c = u.company
        return c.name if c else None

    def get_employee_id(self, u):
        p = getattr(u, "employee_profile", None)
        return p.id if p else None


class ProfileUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ["full_name", "avatar"]


class RegisterCompanySerializer(serializers.Serializer):
    full_name = serializers.CharField(max_length=150)
    phone = serializers.CharField()
    national_id = serializers.CharField(max_length=10)
    company_name = serializers.CharField(max_length=150)
    password = serializers.CharField(min_length=6, write_only=True)

    def validate_phone(self, v):
        v = _phone(v)
        if User.objects.filter(phone=v).exists():
            raise serializers.ValidationError("این شماره قبلاً ثبت شده است.")
        return v

    def validate_national_id(self, v):
        v = normalize_digits(v)
        if not (v.isdigit() and len(v) == 10):
            raise serializers.ValidationError("کد ملی باید ۱۰ رقم باشد.")
        return v

    @transaction.atomic
    def create(self, d):
        user = User.objects.create_user(
            username=d["phone"], phone=d["phone"], password=d["password"],
            full_name=d["full_name"], national_id=d["national_id"], role=User.Role.MANAGER)
        Company = apps.get_model("companies", "Company")
        Company.objects.create(owner=user, name=d["company_name"])
        return user


class LoginSerializer(serializers.Serializer):
    phone = serializers.CharField()
    password = serializers.CharField(write_only=True)

    def validate(self, attrs):
        phone = normalize_phone(attrs["phone"])
        user = authenticate(username=phone, password=attrs["password"])
        if not user:
            raise serializers.ValidationError("شماره موبایل یا رمز عبور اشتباه است.")
        if not user.is_active:
            raise serializers.ValidationError("حساب کاربری غیرفعال است.")
        company = user.company
        if user.role != "manager" or not user.is_staff:
            if company is None:
                raise serializers.ValidationError("حساب شما به هیچ شرکتی متصل نیست.")
            if not company.is_active:
                raise serializers.ValidationError("حساب شرکت غیرفعال شده است. با پشتیبانی تماس بگیرید.")
        attrs["user"] = user
        return attrs


class ChangePasswordSerializer(serializers.Serializer):
    old_password = serializers.CharField()
    new_password = serializers.CharField(min_length=6)
