from django.contrib.auth.models import AbstractUser
from django.db import models


class User(AbstractUser):
    class Role(models.TextChoices):
        MANAGER = "manager", "مدیر"
        EMPLOYEE = "employee", "کارمند"

    phone = models.CharField("شماره موبایل", max_length=11, unique=True, null=True, blank=True)
    full_name = models.CharField("نام و نام خانوادگی", max_length=150, blank=True)
    national_id = models.CharField("کد ملی", max_length=10, blank=True)
    role = models.CharField("نقش", max_length=10, choices=Role.choices, default=Role.EMPLOYEE)
    avatar = models.ImageField("تصویر پروفایل", upload_to="avatars/", null=True, blank=True)

    class Meta:
        verbose_name = "کاربر"
        verbose_name_plural = "کاربران"

    def __str__(self):
        return self.full_name or self.phone or self.username

    @property
    def company(self):
        if self.role == self.Role.MANAGER:
            return getattr(self, "owned_company", None)
        prof = getattr(self, "employee_profile", None)
        return prof.company if prof else None
