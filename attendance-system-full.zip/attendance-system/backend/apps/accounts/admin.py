from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import User


@admin.register(User)
class CustomUserAdmin(UserAdmin):
    list_display = ("phone", "full_name", "role", "is_active", "is_staff", "date_joined")
    list_filter = ("role", "is_active", "is_staff")
    search_fields = ("phone", "full_name", "national_id")
    ordering = ("-date_joined",)
    fieldsets = UserAdmin.fieldsets + (("اطلاعات تکمیلی", {"fields": ("phone", "full_name", "national_id", "role", "avatar")}),)
    add_fieldsets = UserAdmin.add_fieldsets + (("اطلاعات تکمیلی", {"fields": ("phone", "full_name", "role")}),)
