from django.contrib import admin
from .models import Company, Holiday


class HolidayInline(admin.TabularInline):
    model = Holiday
    extra = 0


@admin.register(Company)
class CompanyAdmin(admin.ModelAdmin):
    list_display = ("name", "owner", "is_active", "require_location", "created_at")
    list_filter = ("is_active", "require_location")
    search_fields = ("name", "owner__phone", "owner__full_name")
    inlines = [HolidayInline]
    actions = ["activate", "deactivate"]

    @admin.action(description="فعال‌سازی شرکت‌های انتخاب‌شده")
    def activate(self, request, qs):
        qs.update(is_active=True)

    @admin.action(description="غیرفعال‌سازی شرکت‌های انتخاب‌شده")
    def deactivate(self, request, qs):
        qs.update(is_active=False)
