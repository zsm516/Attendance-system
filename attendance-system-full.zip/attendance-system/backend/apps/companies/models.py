import datetime as dt
from django.conf import settings
from django.db import models


def default_weekend():
    return [4]  # Friday (python weekday)


class Company(models.Model):
    owner = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="owned_company",
                                 verbose_name="مدیر")
    name = models.CharField("نام شرکت", max_length=150)
    is_active = models.BooleanField("فعال", default=True)
    weekend_days = models.JSONField("روزهای تعطیل هفتگی", default=default_weekend,
                                    help_text="شماره روز بر اساس پایتون: دوشنبه=۰ ... جمعه=۴ شنبه=۵ یکشنبه=۶")
    require_location = models.BooleanField("الزام ثبت موقعیت مکانی", default=False)
    latitude = models.DecimalField("عرض جغرافیایی", max_digits=9, decimal_places=6, null=True, blank=True)
    longitude = models.DecimalField("طول جغرافیایی", max_digits=9, decimal_places=6, null=True, blank=True)
    radius_m = models.PositiveIntegerField("شعاع مجاز (متر)", default=150)
    grace_minutes = models.PositiveIntegerField("مهلت تأخیر (دقیقه)", default=10)
    created_at = models.DateTimeField("تاریخ ایجاد", auto_now_add=True)

    class Meta:
        verbose_name = "شرکت"
        verbose_name_plural = "شرکت‌ها"

    def __str__(self):
        return self.name

    def is_holiday(self, d: dt.date) -> bool:
        return d.weekday() in (self.weekend_days or []) or self.holidays.filter(date=d).exists()


class Holiday(models.Model):
    company = models.ForeignKey(Company, on_delete=models.CASCADE, related_name="holidays")
    date = models.DateField("تاریخ")
    title = models.CharField("عنوان", max_length=120, blank=True)

    class Meta:
        verbose_name = "تعطیلی"
        verbose_name_plural = "تعطیلات"
        unique_together = ("company", "date")
        ordering = ["date"]

    def __str__(self):
        return f"{self.company} – {self.date}"
