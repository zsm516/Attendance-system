from rest_framework import viewsets
from rest_framework.response import Response
from rest_framework.views import APIView
from apps.core.permissions import IsManager
from .models import Holiday
from .serializers import CompanySerializer, HolidaySerializer


class CompanyView(APIView):
    def get_permissions(self):
        from rest_framework.permissions import IsAuthenticated
        return [IsManager()] if self.request.method != "GET" else [IsAuthenticated()]

    def get(self, request):
        c = request.user.company
        return Response(CompanySerializer(c).data if c else {})

    def patch(self, request):
        ser = CompanySerializer(request.user.company, data=request.data, partial=True)
        ser.is_valid(raise_exception=True)
        ser.save()
        return Response(ser.data)


class HolidayViewSet(viewsets.ModelViewSet):
    serializer_class = HolidaySerializer
    permission_classes = [IsManager]
    pagination_class = None

    def get_queryset(self):
        return Holiday.objects.filter(company=self.request.user.company)

    def perform_create(self, ser):
        ser.save(company=self.request.user.company)
