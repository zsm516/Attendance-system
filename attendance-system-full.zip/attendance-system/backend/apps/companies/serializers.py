from rest_framework import serializers
from apps.core.jalali import jalali_str
from .models import Company, Holiday


class CompanySerializer(serializers.ModelSerializer):
    class Meta:
        model = Company
        fields = ["id", "name", "weekend_days", "require_location", "latitude", "longitude",
                  "radius_m", "grace_minutes", "created_at"]
        read_only_fields = ["id", "created_at"]

    def validate(self, a):
        inst = self.instance
        req = a.get("require_location", inst.require_location if inst else False)
        lat = a.get("latitude", inst.latitude if inst else None)
        lng = a.get("longitude", inst.longitude if inst else None)
        if req and (lat is None or lng is None):
            raise serializers.ValidationError("برای الزام موقعیت مکانی، مختصات شرکت را وارد کنید.")
        return a

    def validate_weekend_days(self, v):
        if not isinstance(v, list) or any((not isinstance(i, int)) or i < 0 or i > 6 for i in v):
            raise serializers.ValidationError("روزهای تعطیل نامعتبر است.")
        return sorted(set(v))


class HolidaySerializer(serializers.ModelSerializer):
    jalali = serializers.SerializerMethodField()

    class Meta:
        model = Holiday
        fields = ["id", "date", "title", "jalali"]

    def get_jalali(self, o):
        return jalali_str(o.date)
