from django.urls import include, path
from rest_framework.routers import DefaultRouter
from . import views

router = DefaultRouter()
router.register("holidays", views.HolidayViewSet, basename="holiday")
urlpatterns = [path("", views.CompanyView.as_view()), path("", include(router.urls))]
