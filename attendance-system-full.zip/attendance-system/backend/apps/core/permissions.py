from rest_framework.permissions import BasePermission


class IsManager(BasePermission):
    message = "این بخش فقط برای مدیر است."
    def has_permission(self, request, view):
        u = request.user
        return bool(u and u.is_authenticated and u.role == "manager" and getattr(u, "company", None))


class IsEmployee(BasePermission):
    message = "این بخش فقط برای کارمند است."
    def has_permission(self, request, view):
        u = request.user
        return bool(u and u.is_authenticated and hasattr(u, "employee_profile"))
