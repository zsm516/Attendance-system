from rest_framework.views import exception_handler


def api_exception_handler(exc, context):
    resp = exception_handler(exc, context)
    if resp is not None and isinstance(resp.data, dict) and "detail" not in resp.data:
        # Flatten first validation message for easy display in the UI
        for k, v in resp.data.items():
            msg = v[0] if isinstance(v, (list, tuple)) and v else v
            resp.data = {**resp.data, "detail": str(msg) if k == "non_field_errors" else f"{k}: {msg}"}
            break
    return resp
