"""Jalali (Persian) calendar helpers. Storage is always Gregorian; Jalali is a presentation/logic layer."""
import datetime as dt
import jdatetime

MONTHS = ["فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
          "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"]
WEEKDAYS = ["دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه", "یکشنبه"]  # python weekday() order


def to_jalali(d):
    if d is None:
        return None
    if isinstance(d, dt.datetime):
        d = d.date()
    return jdatetime.date.fromgregorian(date=d)


def jalali_str(d):
    j = to_jalali(d)
    return j.strftime("%Y/%m/%d") if j else None


def jalali_long(d):
    j = to_jalali(d)
    return f"{WEEKDAYS[d.weekday() if not isinstance(d, dt.datetime) else d.date().weekday()]} {j.day} {MONTHS[j.month-1]} {j.year}" if j else None


def jalali_month_range(jy, jm):
    """Return (first_gregorian_date, last_gregorian_date) of a Jalali month."""
    first = jdatetime.date(jy, jm, 1).togregorian()
    nxt = jdatetime.date(jy + 1, 1, 1) if jm == 12 else jdatetime.date(jy, jm + 1, 1)
    last = nxt.togregorian() - dt.timedelta(days=1)
    return first, last


def current_jalali_month(today=None):
    j = to_jalali(today or dt.date.today())
    return j.year, j.month


def week_start(d):
    """Persian week starts on Saturday."""
    offset = (d.weekday() - 5) % 7  # Saturday weekday()==5
    return d - dt.timedelta(days=offset)
