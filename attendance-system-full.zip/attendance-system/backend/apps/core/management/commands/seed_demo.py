"""python manage.py seed_demo  – creates a demo company, manager, employees and a week of attendance."""
import datetime as dt
import random
from django.core.management.base import BaseCommand
from django.db import transaction
from django.utils import timezone
from apps.accounts.models import User
from apps.attendance.models import AttendanceRecord
from apps.companies.models import Company
from apps.employees.models import Employee, WorkShift


class Command(BaseCommand):
    help = "Create demo data (manager 09120000000 / demo1234, employees 09121000001.. / demo1234)"

    @transaction.atomic
    def handle(self, *args, **opts):
        if User.objects.filter(phone="09120000000").exists():
            self.stdout.write("Demo data already exists.")
            return
        mgr = User.objects.create_user(username="09120000000", phone="09120000000", password="demo1234",
                                       full_name="مدیر نمونه", national_id="0012345678", role="manager")
        company = Company.objects.create(owner=mgr, name="شرکت نمونه")
        names = ["علی رضایی", "مریم احمدی", "حسین کریمی", "سارا موسوی", "رضا نوری"]
        random.seed(7)
        for i, n in enumerate(names, 1):
            u = User.objects.create_user(username=f"0912100000{i}", phone=f"0912100000{i}", password="demo1234",
                                         full_name=n, role="employee")
            part = i == 5
            e = Employee.objects.create(user=u, company=company, code=str(1000 + i), position="کارشناس",
                                        employment_type="part" if part else "full",
                                        weekly_hours=24 if part else 44,
                                        hired_at=timezone.localdate() - dt.timedelta(days=60))
            days = [5, 6, 0, 1] if part else [5, 6, 0, 1, 2, 3]  # Sat..Wed / Thu
            for wd in days:
                WorkShift.objects.create(employee=e, weekday=wd, start_time=dt.time(8, 0) if not part else dt.time(14, 0),
                                         end_time=dt.time(16, 0) if not part else dt.time(20, 0))
            for back in range(1, 8):
                d = timezone.localdate() - dt.timedelta(days=back)
                sh = e.shift_for(d)
                if not sh or random.random() < 0.1:
                    continue
                s = timezone.make_aware(dt.datetime.combine(d, sh.start_time)) + dt.timedelta(minutes=random.randint(-5, 20))
                f = timezone.make_aware(dt.datetime.combine(d, sh.end_time)) + dt.timedelta(minutes=random.randint(-10, 15))
                late = max(0, int((s - timezone.make_aware(dt.datetime.combine(d, sh.start_time))).total_seconds() // 60))
                AttendanceRecord.objects.create(employee=e, date=d, check_in=s, check_out=f, method="mobile",
                                                late_minutes=late if late > company.grace_minutes else 0)
        self.stdout.write(self.style.SUCCESS("Demo: manager 09120000000 / demo1234 — employees 09121000001..5 / demo1234"))
