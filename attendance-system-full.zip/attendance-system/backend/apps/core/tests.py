import datetime as dt
from django.utils import timezone
from rest_framework.test import APITestCase

BASE = "/api/v1"
SHIFTS = [{"weekday": i, "start_time": "00:00", "end_time": "23:59"} for i in range(7)]


class FlowTests(APITestCase):
    def reg(self, phone="09120000001", company="شرکت الف"):
        r = self.client.post(f"{BASE}/auth/register-company/", {
            "full_name": "مدیر تست", "phone": phone, "national_id": "0012345678",
            "company_name": company, "password": "secret123"}, format="json")
        self.assertEqual(r.status_code, 201, r.data)
        return r.data["access"]

    def auth(self, token):
        self.client.credentials(HTTP_AUTHORIZATION=f"Bearer {token}" if token else "")

    def mk_emp(self, token, phone="09121111111", **kw):
        self.auth(token)
        body = {"full_name": "کارمند", "phone": phone, "password": "emp12345", "employment_type": "full",
                "weekly_hours": 44, "shifts": SHIFTS, **kw}
        r = self.client.post(f"{BASE}/employees/", body, format="json")
        self.assertEqual(r.status_code, 201, r.data)
        return r.data

    def login(self, phone, pw="emp12345"):
        self.auth(None)
        r = self.client.post(f"{BASE}/auth/login/", {"phone": phone, "password": pw}, format="json")
        self.assertEqual(r.status_code, 200, r.data)
        return r.data["access"]

    def test_register_with_stale_token(self):
        self.auth("garbage.token.value")
        self.reg()

    def test_register_validation(self):
        self.auth(None)
        r = self.client.post(f"{BASE}/auth/register-company/", {"full_name": "x", "phone": "123", "national_id": "1",
                             "company_name": "c", "password": "secret123"}, format="json")
        self.assertEqual(r.status_code, 400)

    def test_persian_digits_phone_login(self):
        self.reg(phone="09120000009")
        self.auth(None)
        r = self.client.post(f"{BASE}/auth/login/", {"phone": "۰۹۱۲۰۰۰۰۰۰۹", "password": "secret123"}, format="json")
        self.assertEqual(r.status_code, 200)

    def test_employee_lifecycle_and_punch(self):
        mt = self.reg()
        emp = self.mk_emp(mt)
        self.assertEqual(emp["code"], "1001")
        et = self.login("09121111111")
        self.auth(et)
        self.assertEqual(self.client.get(f"{BASE}/employees/").status_code, 403)  # employee cannot manage
        r = self.client.post(f"{BASE}/attendance/check-in/", {}, format="json")
        self.assertEqual(r.status_code, 201, r.data)
        self.assertTrue(r.data["is_checked_in"])
        self.assertEqual(self.client.post(f"{BASE}/attendance/check-in/", {}, format="json").status_code, 400)
        r = self.client.post(f"{BASE}/attendance/check-out/", {}, format="json")
        self.assertEqual(r.status_code, 200)
        self.assertFalse(r.data["is_checked_in"])
        self.assertEqual(self.client.post(f"{BASE}/attendance/check-out/", {}, format="json").status_code, 400)
        r = self.client.get(f"{BASE}/attendance/my/")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.data["summary"]["present"], 1)
        # manager board
        self.auth(mt)
        b = self.client.get(f"{BASE}/attendance/board/").data
        self.assertEqual(b["total"], 1)
        self.assertEqual(b["counts"]["present"], 1)
        d = self.client.get(f"{BASE}/attendance/employee/{emp['id']}/").data
        self.assertEqual(d["summary"]["present"], 1)
        self.assertEqual(len(d["employee"]["shifts"]), 7)

    def test_geofence(self):
        mt = self.reg()
        self.auth(mt)
        r = self.client.patch(f"{BASE}/company/", {"require_location": True, "latitude": "38.080000",
                              "longitude": "46.291900", "radius_m": 100}, format="json")
        self.assertEqual(r.status_code, 200, r.data)
        self.mk_emp(mt)
        self.auth(self.login("09121111111"))
        self.assertEqual(self.client.post(f"{BASE}/attendance/check-in/", {}, format="json").status_code, 400)
        far = self.client.post(f"{BASE}/attendance/check-in/", {"lat": 35.7, "lng": 51.4}, format="json")
        self.assertEqual(far.status_code, 400)
        ok = self.client.post(f"{BASE}/attendance/check-in/", {"lat": 38.0801, "lng": 46.2919}, format="json")
        self.assertEqual(ok.status_code, 201, ok.data)

    def test_require_location_needs_coords(self):
        self.auth(self.reg())
        r = self.client.patch(f"{BASE}/company/", {"require_location": True}, format="json")
        self.assertEqual(r.status_code, 400)

    def test_offline_sync_idempotent(self):
        mt = self.reg()
        self.mk_emp(mt)
        self.auth(self.login("09121111111"))
        t1 = (timezone.now() - dt.timedelta(hours=3)).isoformat()
        t2 = (timezone.now() - dt.timedelta(hours=1)).isoformat()
        ev = [{"type": "check_out", "time": t2, "client_uuid": "u-2"},
              {"type": "check_in", "time": t1, "client_uuid": "u-1"}]
        r = self.client.post(f"{BASE}/attendance/sync/", {"events": ev}, format="json")
        self.assertEqual(r.status_code, 200, r.data)
        self.assertTrue(all(x["ok"] for x in r.data["results"]), r.data)
        r2 = self.client.post(f"{BASE}/attendance/sync/", {"events": ev}, format="json")
        self.assertTrue(all(x["ok"] and x["duplicate"] for x in r2.data["results"]), r2.data)
        bad = self.client.post(f"{BASE}/attendance/sync/", {"events": [
            {"type": "check_in", "time": (timezone.now() + dt.timedelta(days=2)).isoformat(), "client_uuid": "u-9"}]}, format="json")
        self.assertFalse(bad.data["results"][0]["ok"])

    def test_leave_flow_and_notifications(self):
        mt = self.reg()
        emp = self.mk_emp(mt)
        et = self.login("09121111111")
        self.auth(et)
        tomorrow = (timezone.localdate() + dt.timedelta(days=1)).isoformat()
        r = self.client.post(f"{BASE}/leaves/", {"leave_type": "daily", "start_date": tomorrow, "end_date": tomorrow,
                             "reason": "کار شخصی"}, format="json")
        self.assertEqual(r.status_code, 201, r.data)
        lid = r.data["id"]
        bad = self.client.post(f"{BASE}/leaves/", {"leave_type": "hourly", "start_date": tomorrow, "end_date": tomorrow}, format="json")
        self.assertEqual(bad.status_code, 400)
        self.assertEqual(self.client.post(f"{BASE}/leaves/{lid}/approve/").status_code, 403)
        self.auth(mt)
        self.assertEqual(self.client.get(f"{BASE}/notifications/unread_count/").data["count"], 1)
        self.assertEqual(self.client.get(f"{BASE}/leaves/?status=pending").data["count"], 1)
        self.assertEqual(self.client.post(f"{BASE}/leaves/{lid}/approve/", {"note": "ok"}, format="json").status_code, 200)
        self.assertEqual(self.client.post(f"{BASE}/leaves/{lid}/reject/").status_code, 400)
        self.auth(et)
        self.assertEqual(self.client.get(f"{BASE}/notifications/unread_count/").data["count"], 1)
        days = self.client.get(f"{BASE}/attendance/employee/{emp['id']}/")  # employee forbidden
        self.assertEqual(days.status_code, 403)

    def test_tenant_isolation(self):
        a = self.reg("09120000001", "الف")
        b = self.reg("09120000002", "ب")
        emp = self.mk_emp(a)
        self.auth(b)
        self.assertEqual(len(self.client.get(f"{BASE}/employees/").data), 0)
        self.assertEqual(self.client.get(f"{BASE}/employees/{emp['id']}/").status_code, 404)
        self.assertEqual(self.client.get(f"{BASE}/attendance/employee/{emp['id']}/").status_code, 404)
        self.assertEqual(self.client.delete(f"{BASE}/employees/{emp['id']}/").status_code, 404)

    def test_duplicate_phone_and_code(self):
        mt = self.reg()
        self.mk_emp(mt)
        self.auth(mt)
        r = self.client.post(f"{BASE}/employees/", {"full_name": "x", "phone": "09121111111", "password": "abcdef"}, format="json")
        self.assertEqual(r.status_code, 400)
        r = self.client.post(f"{BASE}/employees/", {"full_name": "x", "phone": "09122222222", "password": "abcdef",
                             "code": "1001"}, format="json")
        self.assertEqual(r.status_code, 400)

    def test_inactive_company_blocks_login(self):
        mt = self.reg()
        self.mk_emp(mt)
        from apps.companies.models import Company
        Company.objects.update(is_active=False)
        self.auth(None)
        r = self.client.post(f"{BASE}/auth/login/", {"phone": "09121111111", "password": "emp12345"}, format="json")
        self.assertEqual(r.status_code, 400)

    def test_holidays_manual_report_csv(self):
        mt = self.reg()
        emp = self.mk_emp(mt)
        self.auth(mt)
        today = timezone.localdate()
        self.assertEqual(self.client.post(f"{BASE}/company/holidays/", {"date": today.isoformat(), "title": "تست"}, format="json").status_code, 201)
        self.assertEqual(self.client.get(f"{BASE}/attendance/board/").data["counts"]["holiday"], 1)
        yday = today - dt.timedelta(days=1)
        r = self.client.post(f"{BASE}/attendance/manual/", {"employee": emp["id"], "date": yday.isoformat(),
                             "check_in": f"{yday}T09:00:00", "check_out": f"{yday}T17:00:00"}, format="json")
        self.assertEqual(r.status_code, 201, r.data)
        self.assertEqual(r.data["worked_minutes"], 480)
        rep = self.client.get(f"{BASE}/reports/monthly/")
        self.assertEqual(rep.status_code, 200)
        self.assertEqual(len(rep.data["rows"]), 1)
        csv = self.client.get(f"{BASE}/reports/monthly.csv")
        self.assertEqual(csv.status_code, 200)
        self.assertIn("text/csv", csv["Content-Type"])
        self.assertEqual(self.client.delete(f"{BASE}/attendance/records/{r.data['id']}/").status_code, 204)

    def test_unauthenticated_401_and_health(self):
        self.auth(None)
        self.assertEqual(self.client.get(f"{BASE}/attendance/today/").status_code, 401)
        self.assertEqual(self.client.get(f"{BASE}/health/").status_code, 200)

    def test_jalali_helpers(self):
        from apps.core.jalali import jalali_month_range, jalali_str
        f, l = jalali_month_range(1403, 12)
        self.assertEqual(jalali_str(f), "1403/12/01")
        self.assertEqual((l - f).days, 29)  # 1403 is a Jalali leap year: Esfand has 30 days
        f2, l2 = jalali_month_range(1404, 12)
        self.assertEqual((l2 - f2).days, 28)  # 1404 is not: Esfand has 29 days
