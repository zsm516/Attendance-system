import re

_FA = "۰۱۲۳۴۵۶۷۸۹"
_AR = "٠١٢٣٤٥٦٧٨٩"
_TABLE = {ord(c): str(i) for i, c in enumerate(_FA)} | {ord(c): str(i) for i, c in enumerate(_AR)}


def normalize_digits(s):
    return str(s).translate(_TABLE).strip() if s is not None else s


def normalize_phone(s):
    s = normalize_digits(s) or ""
    s = re.sub(r"[\s\-+]", "", s)
    if s.startswith("0098"):
        s = "0" + s[4:]
    elif s.startswith("98") and len(s) == 12:
        s = "0" + s[2:]
    elif len(s) == 10 and s.startswith("9"):
        s = "0" + s
    return s


PHONE_RE = re.compile(r"^09\d{9}$")
