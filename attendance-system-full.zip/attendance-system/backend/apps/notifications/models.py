from django.conf import settings
from django.db import models


class Notification(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="notifications")
    kind = models.CharField("نوع", max_length=30, default="info")
    title = models.CharField("عنوان", max_length=150)
    body = models.TextField("متن", blank=True)
    ref = models.CharField("ارجاع", max_length=60, blank=True)
    is_read = models.BooleanField("خوانده‌شده", default=False)
    created_at = models.DateTimeField("زمان", auto_now_add=True)

    class Meta:
        verbose_name = "اعلان"
        verbose_name_plural = "اعلان‌ها"
        ordering = ["-created_at"]


def notify(user, title, body="", kind="info", ref=""):
    return Notification.objects.create(user=user, title=title, body=body, kind=kind, ref=str(ref))
