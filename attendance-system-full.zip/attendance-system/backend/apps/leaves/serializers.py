from rest_framework import serializers
from apps.core.jalali import jalali_str
from .models import LeaveRequest


class LeaveSerializer(serializers.ModelSerializer):
    employee_name = serializers.CharField(source="employee.user.full_name", read_only=True)
    employee_code = serializers.CharField(source="employee.code", read_only=True)
    start_jalali = serializers.SerializerMethodField()
    end_jalali = serializers.SerializerMethodField()
    type_label = serializers.CharField(source="get_leave_type_display", read_only=True)
    status_label = serializers.CharField(source="get_status_display", read_only=True)

    class Meta:
        model = LeaveRequest
        fields = ["id", "employee_name", "employee_code", "leave_type", "type_label", "start_date", "end_date",
                  "start_jalali", "end_jalali", "start_time", "end_time", "reason", "status", "status_label",
                  "review_note", "created_at"]
        read_only_fields = ["status", "review_note", "created_at"]

    def get_start_jalali(self, o):
        return jalali_str(o.start_date)

    def get_end_jalali(self, o):
        return jalali_str(o.end_date)

    def validate(self, a):
        if a["end_date"] < a["start_date"]:
            raise serializers.ValidationError("تاریخ پایان قبل از شروع است.")
        if a.get("leave_type") == "hourly":
            if not (a.get("start_time") and a.get("end_time")):
                raise serializers.ValidationError("برای مرخصی ساعتی، ساعت شروع و پایان لازم است.")
            if a["start_date"] != a["end_date"]:
                raise serializers.ValidationError("مرخصی ساعتی باید در یک روز باشد.")
            if a["end_time"] <= a["start_time"]:
                raise serializers.ValidationError("ساعت پایان باید بعد از شروع باشد.")
        return a
