from django.conf import settings
from django.db import models


class LeaveRequest(models.Model):
    class Type(models.TextChoices):
        DAILY = "daily", "مرخصی روزانه"
        HOURLY = "hourly", "مرخصی ساعتی"
        SICK = "sick", "استعلاجی"
        MISSION = "mission", "ماموریت"

    class Status(models.TextChoices):
        PENDING = "pending", "در انتظار"
        APPROVED = "approved", "تأیید شده"
        REJECTED = "rejected", "رد شده"

    employee = models.ForeignKey("employees.Employee", on_delete=models.CASCADE, related_name="leaves")
    leave_type = models.CharField("نوع", max_length=10, choices=Type.choices, default=Type.DAILY)
    start_date = models.DateField("از تاریخ")
    end_date = models.DateField("تا تاریخ")
    start_time = models.TimeField("از ساعت", null=True, blank=True)
    end_time = models.TimeField("تا ساعت", null=True, blank=True)
    reason = models.TextField("توضیحات", blank=True)
    status = models.CharField("وضعیت", max_length=10, choices=Status.choices, default=Status.PENDING)
    reviewed_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL,
                                    related_name="+")
    reviewed_at = models.DateTimeField(null=True, blank=True)
    review_note = models.CharField("یادداشت مدیر", max_length=250, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "درخواست مرخصی"
        verbose_name_plural = "درخواست‌های مرخصی"
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.employee} {self.start_date}→{self.end_date} ({self.status})"
