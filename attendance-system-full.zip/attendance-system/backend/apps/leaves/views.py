from django.utils import timezone
from rest_framework import viewsets, mixins
from rest_framework.decorators import action
from rest_framework.exceptions import ValidationError
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from apps.core.permissions import IsEmployee, IsManager
from apps.notifications.models import notify
from .models import LeaveRequest
from .serializers import LeaveSerializer


class LeaveViewSet(mixins.CreateModelMixin, mixins.ListModelMixin, mixins.RetrieveModelMixin,
                   mixins.DestroyModelMixin, viewsets.GenericViewSet):
    serializer_class = LeaveSerializer
    permission_classes = [IsAuthenticated]

    def get_permissions(self):
        if self.action == "create":
            return [IsEmployee()]
        if self.action in ("approve", "reject"):
            return [IsManager()]
        return super().get_permissions()

    def get_queryset(self):
        u = self.request.user
        qs = LeaveRequest.objects.select_related("employee__user")
        if u.role == "manager":
            qs = qs.filter(employee__company=u.company)
        else:
            qs = qs.filter(employee__user=u)
        st = self.request.query_params.get("status")
        return qs.filter(status=st) if st else qs

    def perform_create(self, ser):
        emp = self.request.user.employee_profile
        leave = ser.save(employee=emp)
        notify(emp.company.owner, "درخواست مرخصی جدید",
               f"{emp.user.full_name} درخواست {leave.get_leave_type_display()} ثبت کرد.", "leave", leave.id)

    def perform_destroy(self, inst):
        if inst.employee.user != self.request.user or inst.status != "pending":
            raise ValidationError("فقط درخواست‌های در انتظارِ خودتان قابل حذف است.")
        inst.delete()

    def _review(self, request, status):
        leave = self.get_object()
        if leave.status != "pending":
            raise ValidationError("این درخواست قبلاً بررسی شده است.")
        leave.status = status
        leave.reviewed_by = request.user
        leave.reviewed_at = timezone.now()
        leave.review_note = request.data.get("note", "")[:250]
        leave.save()
        word = "تأیید" if status == "approved" else "رد"
        notify(leave.employee.user, f"درخواست مرخصی {word} شد", leave.review_note, "leave", leave.id)
        return Response(self.get_serializer(leave).data)

    @action(detail=True, methods=["post"])
    def approve(self, request, pk=None):
        return self._review(request, "approved")

    @action(detail=True, methods=["post"])
    def reject(self, request, pk=None):
        return self._review(request, "rejected")
