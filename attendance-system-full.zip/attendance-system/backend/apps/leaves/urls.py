from rest_framework.routers import DefaultRouter
from . import views

router = DefaultRouter()
router.register("", views.LeaveViewSet, basename="leave")
urlpatterns = router.urls
