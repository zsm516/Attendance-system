from django.contrib import admin
from .models import LeaveRequest


@admin.register(LeaveRequest)
class LeaveAdmin(admin.ModelAdmin):
    list_display = ("employee", "leave_type", "start_date", "end_date", "status", "created_at")
    list_filter = ("status", "leave_type")
    search_fields = ("employee__user__full_name", "employee__code")
